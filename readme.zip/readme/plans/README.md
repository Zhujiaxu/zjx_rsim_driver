# plans/ — 待做计划协议

每条 plan 是一份「可被另一个 agent 接力执行」的实现计划。每份 plan 一个 markdown，平铺在 `plans/` 下，不再分子目录。**与 issues/ 一样按 scope 标签区分 root 子项目（DLG/ORC/FMU/RFR/TM/X）**，但 scope 体现在文件名而不是子目录上。

DVM 相关 plan 只在 `../../dynamic_vehicle_module/readme/plans/` 维护；root 侧不再复制 DVM、RSimPhysics/DVM 耦合、FMI2/FMI3 mixed orchestrator、edge timing static、async run 性能优化等计划正文。

## 文件命名

```
<日期>-<scope>-<动词-对象>.md
```

例：
- `2026-05-08-ORC-fix-step-alignment.md`
- `2026-05-09-FMU-add-variable-metadata-check.md`
- `2026-05-09-X-unify-yaw-utils.md`

日期取**创建日期**，不要因延期改名（延期写在「状态」里）。

---

## plan 模板

```markdown
# <一句话标题>

- 来源 issue: [BLOCK-ORC-01] [HIGH-X-03]   # 多条用空格分隔；可链接 investigations/...
- 创建日期: 2026-05-08
- 负责: agent / user / 客户
- 状态: 🟡 待开工 / 🟠 进行中 / ✅ 已完成 / 🔴 暂缓 / ⛔ 取消

## 改进目标（强制三栏，不允许简略）

### 目标状态（系统改完后是什么样）
- 例：orchestrator 与 TimeManager 的 step 对齐策略一致，0.02s 主步内嵌套 0.001s 子步，子步累计误差 < 1e-9。

### 约束（不允许越界的边界）
- 不引入新的全局可变状态。
- 不修改 FMI 标准接口签名。
- 不破坏 [BLOCK-ORC-01..05] 已确认的字段。
- 单步耗时不超过现状 2×。

### 成功指标（怎么知道到了）
- 跑 `./dev_workflow.sh test replay` 通过，无新增 warning。
- 用 `tools/step_drift_check.py` 处理 build/dev_loop_logs 最新日志，drift < 1e-9。
- 现场录包重放 5 次结果一致（同 seed）。

## 背景 / 现状

- 关键代码: `orchestrator/src/FmuOrchestratorCore.cpp:120`、`TimeManager/...`
- 关键文档: `../../orchestrator/orchestrator中间件重构_617b0d36.plan.md`、`../../readme.txt`
- 已有现象 / 录包: investigations/<某个调查>.md

## 任务列表（干预设计）

- [ ] T1: <动作> —— <验收>
- [ ] T2: <动作> —— <验收>
- [ ] T3: <动作> —— <验收>

> 任务粒度建议「半天到一天能完成且能单独提 PR」。

## 验证项（反馈环）

- [ ] V1: 跑 `<命令>`，看 `<日志/输出>`，期望 `<现象>`
- [ ] V2: 用 `pytest tests/...` 通过；新增回归用例 `test_xxx`
- [ ] V3: 现场录包 `<场景>`，对照 `<指标>` 在 `<期望区间>`

> 每条 V 都要写「跑什么 / 看什么 / 期望什么」，不要只写「测一下」。验证项必须能映射到「成功指标」其中一条。

## 风险 / 已知坑

- <可能改坏什么、依赖什么外部条件>

## 讨论

- (Agent 2026-05-08) 起 plan，T1 优先做……
- (User) ...
- (Agent 2026-05-09) T1 done，commit abc123；走 V1 通过；T2 阻塞，等 user 回复 [HIGH-X-04]
```

---

## 为什么强制「目标 / 约束 / 成功指标」三栏

系统思考方法把「改进目标」与「干预设计」拆成两个不同阶段（参见顶层 `../README.md` 的 FAST 骨架对应）。如果一份 plan 只写任务列表不写目标三栏，会出现：

- **任务做完了但没人知道是不是到达目标**（缺成功指标）
- **为完成任务而违反隐含边界**（缺约束）
- **不同 agent 接力时各做各的「目标」**（缺目标状态）

所以「目标三栏」是 plan 的入场券，不是装饰。

---

## 状态机

| 图标 | 状态 | 含义 |
|------|------|------|
| 🟡 | 待开工 | 已立项，未开始 |
| 🟠 | 进行中 | 至少一项 T 已开工 |
| ✅ | 已完成 | 所有 T 与所有 V 通过；附 commit/PR |
| 🔴 | 暂缓 | 暂停推进；写明原因与解锁条件 |
| ⛔ | 取消 | 不再推进；不删除文件 |

## 与 issues/ 的关系

- 一条 issue 走到 🟢 → 派生一份 plan；plan 完成后回 issue 标 ✅，并把 plan 路径写进 issue 的「讨论」。
- 一份 plan 可解决多条 issue；所有相关 issue 都要在「来源 issue」里列出。
- plan 中途**不允许**改源 issue 的状态（除非 plan 完成）；source 与 sink 分离。

## 维护规则

- 每次推进 plan，至少更新一项任务勾选 + 一行讨论；空更新会让 review 失去时间感。
- 完成 commit 必须在 plan 里以 `commit <短 sha>: <信息>` 引用，便于回溯。
- 如果 plan 在执行中发现 issue 描述错误，**先回 issue 修描述**（讨论里写 `(Agent) 描述更新`），再继续 plan，避免两边描述漂移。
- 取消（⛔）时写明：什么前提变了、是否需要重开新 plan。
- 如果在执行中发现「成功指标其实达不到」或「约束过紧」，**回头改目标三栏**而不是放弃验证；改前后都要在讨论里留痕。
