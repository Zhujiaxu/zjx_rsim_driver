# dataloger 多维参数表与插值管理器

- 来源 issue: 用户请求（2026-06-09，多维矩阵 / FMI3 参数表 / 起步增益标定）
- 创建日期: 2026-06-09
- 负责: agent / user
- 状态: 🟠 进行中

## 改进目标

### 目标状态

- 在 `dataloger` 体系中提供一套工业化、可复用的多维参数表基础设施，用于车辆模型内部标定表、增益表、扭矩表、换挡阈值表等配置。
- `VehicleLogger` 继续负责当前仿真变量的标量存取和时间版本管理；多维表格的解析、校验、插值和越界策略由新的 `RSimTableManager` / `LookupTableManager` 负责。
- 表格访问方式与现有 logger 索引风格一致，模型代码可通过字符串表名和坐标向量查询结果，例如 `lookup("PTU_StartGain", {throttle, vx})`。
- 首批支持 1D / 2D `double` 表，后续可扩展到 N-D、多种越界策略、`int` 离散表和 FMI3 数组参数输入。
- FMI3 侧能够用数组变量或配置文件表达表格数据；FMI 只负责数据传输和维度元数据，具体插值语义由本项目实现。

### 约束

- 不把插值、越界、表格解析逻辑塞入 `VehicleLogger`，避免数据记录器承担标定系统职责。
- 不大改现有 `DataLogger.hpp` 的标量类型存储结构；首期尽量只增加独立 manager 和必要的元数据字段。
- 不复制 `CSV_fmuModel` 的场景回放逻辑到车辆模型内部；只复用其中成熟的思想和少量可抽象的查表经验。
- 不在首期实现过度泛化的 FMI3 structural parameter 动态维度；先支持固定维度数组或资源配置文件，保证落地稳定。
- 不改变现有 `VehicleValue<T>(key, default)` 的语义，不破坏已有 FMU Get/Set、CSV 输出和实验回放流程。
- 对 `int` 表不默认线性插值；离散状态、挡位、模式类表应默认 nearest / step，避免产生无物理意义的中间值。
- 表格配置失败必须在初始化阶段给出明确错误，包括轴非单调、维度不匹配、值数量不正确、表名重复、坐标维度错误等。

### 成功指标

- 新增表格管理模块能在不影响现有 `VehicleLogger` 标量读写的前提下，通过单元测试验证 1D 线性插值、2D 双线性插值和 clamp 越界。
- 能注册一张起步增益表，例如 `PTU_StartGain = f(throttle, vx)`，模型代码查询后得到确定、可复现的增益值。
- 能通过 FMI3 固定数组参数或资源配置文件修改表格内容，不需要重新编译模型即可调整标定值。
- 对错误表格配置有失败测试覆盖，不能静默填 0、静默截断或使用错误维度继续运行。
- 原有 `dataloger` 测试、`CSV_fmuModel` 回放、`ExperimentModule` 实验流程继续通过或不受影响。

## 背景 / 现状

- 当前 `dataloger/include/DataLogger.hpp` 的核心能力是按字符串 key 存储标量最新值，类型由 `RSimTypes.hpp` 中的支持类型决定，并带有仿真时间、帧号和写入版本。
- 当前 `dataloger/include/VariableRegistry.hpp` 负责变量元数据和 FMI valueReference 映射，但 `VariableMeta` 主要描述标量变量，尚未系统描述数组维度、表格角色、轴和值之间的关系。
- `CSV_fmuModel` 已有 CSV 驱动的查表能力，支持时间序列、多输出 2D 和简单网格表，但该模型定位是场景数据回放 / CSV 输出，不适合作为车辆模型内部标定表的核心依赖。
- `CSV_fmuModel/CSV_sourse/Data/LookupTable2D.*` 可作为 1D 曲线插值参考；`LookupTable3DInterp.hpp` 实际更接近“两轴输入、一值输出”的 2D 网格插值，命名和实现都偏历史遗留，不建议直接作为通用 N-D 基础。
- FMI3 标准可以通过 `<Dimension>` 描述数组变量，多维矩阵按一维数组展平传入；但 FMI 标准不定义查表插值语义，因此插值、越界和表格校验必须由 FMU 内部实现。

## 方案判断

推荐采用“轻量扩展 dataloger + 独立表格管理器”的方案。

```text
VehicleLogger       -> 存取当前仿真标量变量
VariableRegistry    -> 管理变量、数组、表格元数据
RSimTableManager    -> 管理表格注册、校验、插值、越界策略
模型代码            -> 读取 VehicleLogger 标量输入，调用 table manager 查询标定结果
```

不推荐把 `DataLogger` 扩成直接存表并负责插值。原因是：

- `DataLogger` 的强项是仿真时序数据，不是标定参数系统。
- 插值策略、维度校验、越界策略会显著增加 logger 复杂度。
- 未来表格可能来自 FMI 数组、XML、CSV、Binary 或客户标定文件；独立 manager 更容易统一入口。
- 表格一般是初始化参数或 tunable 参数，不应该像 `Vx`、`Ax` 一样每帧写入最新值。

## 拟定数据结构

首期建议新增独立头文件，例如 `dataloger/include/RSimTableManager.hpp` 和 `dataloger/include/LookupTableND.hpp`。

```cpp
enum class TableElementType {
    Int,
    Double
};

enum class TableInterpMode {
    Nearest,
    Linear
};

enum class TableExtrapMode {
    Clamp,
    Constant,
    Linear,
    Fail
};

struct LookupTableND {
    std::string name;
    TableElementType elementType = TableElementType::Double;
    TableInterpMode interpMode = TableInterpMode::Linear;
    TableExtrapMode extrapMode = TableExtrapMode::Clamp;

    std::vector<std::vector<double>> axes;
    std::vector<size_t> shape;
    std::vector<double> values;
};
```

设计说明：

- `axes.size()` 是维度数，例如 1D 为 `{throttle}`，2D 为 `{throttle, speed}`。
- `shape[i] == axes[i].size()`。
- `values` 使用固定的展平顺序，建议明确为 row-major，并在文档和测试中固定。
- `double` 表支持线性 / 多线性插值。
- `int` 表首期可存成 double 内部值，但 API 上标记为离散表，默认 nearest / step 查询。

## 拟定 manager 接口

```cpp
class RSimTableManager {
public:
    static RSimTableManager& instance();

    bool registerTable(const LookupTableND& table);
    bool hasTable(const std::string& name) const;
    const LookupTableND* findTable(const std::string& name) const;

    double lookup(const std::string& name,
                  const std::vector<double>& coordinates) const;

    bool setTableValues(const std::string& name,
                        const std::vector<double>& flatValues);

    bool validateTable(const LookupTableND& table,
                       std::string* errorMessage = nullptr) const;
};
```

首期接口保持简洁：

- `registerTable()` 只在初始化或 tunable 参数更新时调用。
- `lookup()` 是模型运行时主入口，需要做到无异常或少异常、错误可控。
- manager 内部使用 mutex 保护注册 / 更新；高频 lookup 可考虑读写锁或初始化后只读。
- 若后续性能压力明显，可把模型常用表缓存为 `const LookupTableND*` 或轻量 handle，避免每步字符串查找。

## FMI3 接入方案

### 方案 A：固定维度数组参数

适合起步增益、扭矩曲线、换挡阈值这类尺寸稳定的标定表。

```xml
<Float64 name="PTU_StartGain_ThrottleAxis" valueReference="3001"
         causality="parameter" variability="tunable" initial="exact"
         start="0 0.1 0.2 0.4 0.6 0.8 1.0">
  <Dimension start="7"/>
</Float64>

<Float64 name="PTU_StartGain_SpeedAxis" valueReference="3002"
         causality="parameter" variability="tunable" initial="exact"
         start="0 0.5 1.0 2.0 4.0">
  <Dimension start="5"/>
</Float64>

<Float64 name="PTU_StartGain_Values" valueReference="3003"
         causality="parameter" variability="tunable" initial="exact"
         start="... flattened row-major ...">
  <Dimension start="7"/>
  <Dimension start="5"/>
</Float64>
```

初始化流程：

1. `VariableRegistry` 解析并记录数组维度。
2. `fmi3SetFloat64()` 接收展平数组时检查 `nValues` 是否等于维度乘积。
3. `ExitInitializationMode()` 或参数更新后，用 axis/value 组装 `LookupTableND`。
4. `RSimTableManager` 校验成功后注册表格。

### 方案 B：资源 CSV / XML 配置文件

适合尺寸可能变化、客户标定文件频繁替换、表格较大的场景。

```xml
<String name="PTU_StartGain_TablePath" valueReference="3010"
        causality="parameter" variability="fixed"
        start="resources/tables/ptu_start_gain.csv"/>
```

优点：

- 不需要 FMI structural parameter。
- 表格尺寸可变。
- 客户交付和实验替换更直观。

缺点：

- Host 不能直接通过 `fmi3SetFloat64()` 修改每个表格点。
- 需要定义稳定的 CSV / XML 表格格式。

### 首期建议

优先做方案 B 或固定维度方案 A，不急于做动态 structural parameter。对于当前“0-1 油门开度对应不同增益”的问题，最小可用方案是：

- 1D：`gain = f(throttle)`
- 更推荐 2D：`gain = f(throttle, vehicle_speed)`

2D 方案能把增益限制在起步低速阶段，避免破坏中高速扭矩和换挡已经校准好的结果。

## 与当前代码的复用关系

- 复用 `VariableRegistry` 的 name / VR 映射能力，但只增加数组和表格元数据，不改变标量变量路径。
- 复用 `RSimTypes.hpp` 的类型枚举思路，必要时增加数组角色或表格角色，不急于把 `std::vector<double>` 加入 `RSIM_SUPPORTED_TYPES`。
- 参考 `LookupTable2D` 的线性插值实现，但新实现应统一 1D / 2D / N-D 的展平索引和校验规则。
- 参考 `CSV_fmuModel` 的缺数不静默填 0、越界策略显式配置、初始化失败报错方式。
- 不让车辆动力模型直接依赖 `CSV_fmuModel`；表格基础能力应放在 `dataloger` 或公共基础库中。
- 表格属于 `dataloger` 体系内的参数/标定数据，但不进入 `RSIM_SUPPORTED_TYPES` 和 `VehicleLogger::Snapshot`。这样现有 `VehicleLogger`、`CsvSerializer`、实验 CSV 仍只处理标量时序数据，不受多维表格影响。
- FMI3 没有单独的 `GetArray/SetArray` 接口；数组变量仍通过 `fmi3GetFloat64` / `fmi3SetFloat64` 等 typed Get/Set 传输。区别在于一个 valueReference 可以展开为多个 `values[]` 元素，因此实现时必须用 `VariableMeta::elementCount` 推进 `index`，不能再假设 `nValues == nValueReferences`。
- `<Annotation type="com.rsim.tables">` 首期只描述“哪些轴和值数组组成哪张表”，不自动声明每步输入输出映射。车辆模型内部标定表建议由模型代码显式读取当前输入并调用 `lookup()`，这样更容易处理滤波、限幅、低速启用条件和模型上下文。
- 若后续要做通用查表 FMU，可在 Annotation 中额外描述 `<Input>` / `<Output>`，由该 FMU 每步自动读输入并写输出；这不作为车辆动力模型内部标定表的首期目标。
- FMI 标准没有“表格”特殊类型；表格在 FMI 中表现为数组变量。因此它可以是 `parameter/fixed`、`parameter/tunable`，理论上也可以是 `input/continuous` 数组。当前车辆标定表建议优先作为 fixed/tunable parameter，不建议作为每步变化的 input array。

## 起步增益示例

当前实验现象：

- 低油门开度下，仿真车起步快于实车，说明低油门起步增益或低速扭矩偏大。
- 高油门开度下，实车起步快于仿真车，说明高油门区实际扭矩请求或增益可能更大。
- 只使用一个全局 `PTU_ThrottleGain` 会同时影响所有油门开度，容易修好一端、破坏另一端。

建议表格：

```text
PTU_StartGain = f(throttle, vx)
```

示例轴：

```text
throttle axis: 0.0, 0.1, 0.2, 0.4, 0.6, 0.8, 1.0
speed axis:    0.0, 0.5, 1.0, 2.0, 4.0
```

标定方向：

- 低 throttle、低 speed：gain 小于 1，降低仿真起步冲击。
- 高 throttle、低 speed：gain 大于 1，提高高油门起步响应。
- speed 升高后 gain 逐渐回到 1，避免影响中高速换挡和巡航段。

模型侧使用方式：

```cpp
const double throttle = VehicleValue<double>("REF_TorqueRequest", 0.0);
const double vx = VehicleValue<double>("Vx", 0.0);
const double gain = RSimTableManager::instance()
    .lookup("PTU_StartGain", {throttle, vx});
```

## 任务列表

- [x] T1: 增加表格数据结构和校验逻辑 —— 新增 `LookupTableND`，校验表名、维度、轴单调性、shape/value 数量、插值模式和越界模式。
- [x] T2: 实现 1D / 2D 查询 —— 先实现 1D linear / nearest 和 2D bilinear / nearest，越界首期支持 clamp 和 fail。
- [x] T3: 增加 `RSimTableManager` —— 支持注册、查找、更新 values、lookup，并保证初始化后只读路径清晰。
- [x] T4: 扩展 `VariableRegistry` 元数据 —— 增加数组维度和表格角色字段，使 FMI Get/Set 能判断 `nValues` 是否正确。
- [x] T5: 接入一种配置入口 —— 在固定维度 FMI3 数组参数或资源 CSV/XML 配置中二选一先落地，形成可运行样例。
- [x] T6: 在 PTU / 起步增益路径中试用 —— 用 `PTU_StartGain=f(throttle,vx)` 替代单一全局增益参数，保留默认表为全 1，确保默认行为不变。
- [x] T7: 增加单元测试和实验验证 —— 覆盖表格校验、插值、越界、错误配置、FMI 参数注入和 SANY 起步响应对比。
- [ ] T8: 文档化表格格式和使用规范 —— 写明 row-major 展平顺序、轴要求、int 表限制、越界策略和模型接入范式。

## 验证项

- [x] V1: 运行 dataloger 单元测试，验证现有标量 `log/getLastValue` 行为不变。
- [x] V2: 新增 1D 插值测试：轴 `[0, 1]`、值 `[1, 3]`，查询 `0.5` 得到 `2.0`。
- [x] V3: 新增 2D 插值测试：构造简单平面 `z=x+y`，查询多个网格内点，误差小于 `1e-12`。
- [x] V4: 新增越界测试：clamp 模式下越界查询返回边界插值结果；fail 模式下返回错误或可诊断状态。
- [x] V5: 新增错误配置测试：轴非单调、shape 不匹配、values 数量错误均初始化失败，并输出明确错误信息。
- [x] V6: 若接 FMI 数组参数，运行一次 `fmi3SetFloat64(vr, nValues=N)`，验证正确长度通过、错误长度失败。
- [x] V7: 用 SANY 起步实验验证低油门和高油门响应：低油门起步不再明显快于实车，高油门起步不再明显慢于实车，且中高速换挡误差不显著恶化。

## 风险 / 已知坑

- FMI3 数组变量的维度和 `nValues` 检查必须严格，否则表格错位后很难从实验曲线反推问题。
- N-D 多线性插值容易在展平索引顺序上出错，必须用小型人工表做单元测试固定语义。
- 表格值若允许运行时更新，需要明确更新时机；首期建议只允许 initialization/tunable 阶段更新，避免 DoStep 中表格被并发修改。
- `int` 表格如果误用线性插值，会产生无意义状态；应在 manager 层禁止或强制 nearest。
- 起步增益表如果只按 throttle，不按 speed，可能破坏中高速动力学匹配；建议优先采用 throttle-speed 2D 表。
- 资源 CSV 表格格式若与 `CSV_fmuModel` 场景 CSV 混用，需要清晰命名和目录隔离，例如 `resources/tables/`，避免实验回放数据和标定表混淆。

## 讨论

- (Agent 2026-06-09) 阅读 `readme/`、`dataloger/include/DataLogger.hpp`、`dataloger/include/VariableRegistry.hpp`、`CSV_fmuModel` README 和现有查表代码后起草本 plan。结论是：多维参数表应作为 dataloger 体系中的独立基础设施建设，但不应把 `VehicleLogger` 本身改成插值系统。首期以 1D / 2D double 表和 `RSimTableManager` 为核心，尽量复用当前变量注册、FMI 元数据和 CSV 模型中的查表经验。
- (User 2026-06-09) 确认四点设计问题：FMI3 是否支持数组 Get/Set、表格是否应进入 `RSIM_SUPPORTED_TYPES`、Annotation 是否要描述每步输入输出、表格在 FMI 中是否区分 parameter/input。
- (Agent 2026-06-09) 补充结论：FMI3 通过 typed Get/Set 的 `nValues` 支持数组变量，没有单独 `GetArray/SetArray`；表格不进入 `RSIM_SUPPORTED_TYPES`，但仍属于 dataloger 体系中的 `RSimTableManager` 管理；车辆模型内部标定表首期由模型代码显式调用 `lookup()`，不做 Annotation 自动每步输入输出；表格在 FMI 中本质是数组变量，首期按 fixed/tunable parameter 处理，不做每步 input array。
- (Agent 2026-06-09) 完成 T1-T3：新增 `dataloger/include/LookupTableND.hpp` 和 `dataloger/include/RSimTableManager.hpp`，实现表名/维度/轴单调/value 数量/有限值/int 表插值模式校验，支持 row-major N-D linear、nearest、clamp/constant hold 与 fail 越界；`RSimTableManager` 支持注册、查找、更新 values、lookup 和测试清理。更新 `dataloger/src/main.cpp`，增加 1D、2D、clamp、fail、坏轴配置、int nearest 测试；同时把已有测试中 `updatedInCurrentFrame()` 的断言修正为当前实现语义，并将 FMI XML 测试路径改为基于 `__FILE__` 定位，避免依赖运行目录。
- (Agent 2026-06-09) 验证：旧 `dataloger/build` 目录属于 `nobody:nogroup`，无法写入，因此使用 `/tmp/rsim_dataloger_table_build` 进行干净构建。执行 `cmake -S /mnt/new/Rsim_helper/AccumulatedExperience/basic_model/dataloger -B /tmp/rsim_dataloger_table_build -DCMAKE_BUILD_TYPE=Debug`、`cmake --build /tmp/rsim_dataloger_table_build --target datalogger_test -j4`、`./datalogger_test` 均通过。测试输出包含“log基本功能测试通过”“多维表格基础功能测试通过”“FMI XML 反序列化测试通过”。
- (Agent 2026-06-09) 安装：执行 `cmake --install /tmp/rsim_dataloger_table_build --prefix /mnt/new/Rsim_helper/AccumulatedExperience/basic_model/.local_prefix`，新增头文件已安装到 `.local_prefix/include/datalogger/LookupTableND.hpp` 和 `.local_prefix/include/datalogger/RSimTableManager.hpp`，供下游 FMU 工程引用。
- (Agent 2026-06-09) 完成 T4/T5：`VariableMeta` 增加 `isArray`、`dimensions`、`elementCount`、数组默认值和表格角色字段；`VariableRegistry` 增加数组 Get/Set、元素数量查询、元数据更新和变量快照列表。`FmiXmlSchemaDeserializer` 支持 FMI3 `<Dimension start="...">`、数组 `start` 列表解析、非自闭合变量块聚合，以及 `<Annotation type="com.rsim.tables">` 下的 `<Table>` / `<Axis>` 关系；解析后会注册 `RSimTableBinding` 并从数组参数重建 `LookupTableND`。`RSimfmi3Functions.cpp` 的 `fmi3GetFloat64` / `fmi3SetFloat64` 已改为按 `elementCount` 展开/消费 `values[]`，数组 Set 后会触发相关表格重建。数组参数仍不进入 `VehicleLogger::Snapshot`，因此现有 CSV 序列化链路不变。
- (Agent 2026-06-09) 验证 T4/T5：在 `dataloger/src/main.cpp` 中新增运行时 XML fixture，声明 `TableTest_XAxis`、`TableTest_YAxis`、`TableTest_Values` 三个 FMI3 数组变量和 `com.rsim.tables` Annotation，验证 XML 解析后 `VariableRegistry` 能拿到维度/数组默认值，`RSimTableManager` 能注册 `TableTest_Gain` 并正确插值；随后通过 `VariableRegistry::setFloat64ArrayByVr(9003, ...)` 更新 values 并重建表，验证结果从 `1.25` 变为 `11.25`。执行 `cmake -S .../dataloger -B /tmp/rsim_dataloger_table_build -DCMAKE_BUILD_TYPE=Debug && cmake --build /tmp/rsim_dataloger_table_build --target datalogger_test -j4 && /tmp/rsim_dataloger_table_build/datalogger_test` 通过，输出包含“FMI3 数组表格反序列化测试通过”。
- (Agent 2026-06-09) 下游编译验证：执行 `cmake --install /tmp/rsim_dataloger_table_build --prefix /mnt/new/Rsim_helper/AccumulatedExperience/basic_model/.local_prefix` 后，新建 `/tmp/rsim_fmu_table_build` 并用 `-DCMAKE_PREFIX_PATH=/mnt/new/Rsim_helper/AccumulatedExperience/basic_model/.local_prefix` 配置 `fmu_model`，再执行 `cmake --build /tmp/rsim_fmu_table_build --target ExperimentModule -j4` 通过。原 `fmu_model/build` 缓存仍指向 `/usr/local/include/datalogger` 的旧安装，所以未在旧 build 目录内强行覆盖系统 datalogger。
- (Agent 2026-06-09) 完成 T6：`TorqueDistModel` 增加 `PTU_StartGain=f(PTU_Throttle, PTU_StartGainSpeed)` 查表路径，默认通过 `RSimTableManager::lookupOrDefault(..., 1.0)` 保持原行为；`PTU_StartGainSpeed` 首期作为速度坐标，SANY 集成中接 gearbox `AV_Motor2`，避免新增车辆速度链路；新增输出 `PTU_StartGain` 便于 CSV/诊断查看。`TorqueDistModel/modelDescription.xml` 与 `resources/configs/ptu_sany_2source.xml` 均新增 `PTU_StartGain_ThrottleAxis`、`PTU_StartGain_SpeedAxis`、`PTU_StartGain_Values` 三个 FMI3 数组参数和 `com.rsim.tables` Annotation，默认 2x2 全 1 表；`RsimVehicle_SANY/modelDescription.xml` 增加 `PTU_StartGainSpeed` 连接和 `PTU_StartGain` 回写 Self。
- (Agent 2026-06-09) 验证 T6：使用 `.local_prefix` 新建 `/tmp/rsim_torquedist_t6_build`，执行 `cmake -S .../fmu_model -B /tmp/rsim_torquedist_t6_build -DPKG_NAME=TorqueDistModel -DCMAKE_BUILD_TYPE=Debug -DCMAKE_PREFIX_PATH=.../.local_prefix`、`cmake --build /tmp/rsim_torquedist_t6_build --target fmu_TorqueDistModel -j4`、`/tmp/rsim_torquedist_t6_build/TorqueDistModel_test` 通过。测试覆盖 direct、默认 throttle、regen，以及通过 `fmi3SetFloat64(vr=52,nValues=4)` 把 `PTU_StartGain_Values` 更新为 `{2,1,2,1}` 后，`throttle=0.5`、低速下 `PTU_StartGain=2`，总目标扭矩从默认 75 Nm 提升到 150 Nm。另新建 `/tmp/rsim_sany_t6_build` 构建 `fmu_RsimVehicle_SANY` 通过，`build/RsimVehicle_SANY/modelDescription.xml` 已包含 `PTU_StartGainSpeed` 和 `PTU_StartGain` 连接；`build/TorqueDistModel/resources/configs/ptu_sany_2source.xml` 已包含新表格参数。
- (Agent 2026-06-09) 补充验证 V6：`TorqueDistModelTest` 增加数组长度错误断言，先用 `fmi3SetFloat64(vr=52,nValues=3)` 写入 2x2 的 `PTU_StartGain_Values`，要求返回非 `fmi3OK`；再用 `nValues=4` 正确写入并完成起步增益测试。重新执行 `cmake --build /tmp/rsim_torquedist_t6_build --target fmu_TorqueDistModel -j4`、`cmake --build /tmp/rsim_sany_t6_build --target fmu_RsimVehicle_SANY -j4` 和 `/tmp/rsim_torquedist_t6_build/TorqueDistModel_test` 均通过。
- (Agent 2026-06-09) 执行 T7 多轮 SANY 起步增益实验。新增 `tools/run_sany_startgain_calibration.py`，该脚本可批量写入 `PTU_StartGain` 候选表、逐段切换 `CSV_Path`、运行 `ExperimentModule_test`、汇总 `vmax` 偏差、早期速度偏差、换挡延迟并生成图文报告。实验使用 32 段 `sany_flat_start_segments_vcu_state5` 数据，先跑 baseline/mild/strong_low/balanced；结果显示原先“低油门继续加增益”的方向会放大低油门早期偏快问题，因此第二轮改为低油门低速 gain 小于 1、高油门低速 gain 大于 1，速度升高后回到 1。
- (Agent 2026-06-09) T7 Round2 / Round3 结果：综合评分采用 `0.35*vmax_abs_mean + 0.45*early_abs_mean + 0.20*shift_delay_abs_mean`，优先关注起步早期响应，同时约束最高速度和换挡。三轮候选中 `launch_shape_c` 最优，score 从 baseline `0.528858` 降到 `0.520373`；`round3_c_mid` 非常接近，score `0.520701`，但高油门和换挡整体略弱，因此未采用。最终选择 `launch_shape_c`，轴为 throttle `[0, 0.1, 0.2, 0.4, 0.6, 0.8, 1]`、speed rpm `[0, 300, 700, 1200, 5000]`，低油门 0.1/0.2 起步 gain 分别为 `0.78/0.86`，60%-100% 高油门起步 gain 为 `1.16/1.15/1.03`，并在 1200 rpm 后回到 1。
- (Agent 2026-06-09) T7 最终固化与验证：将 `launch_shape_c` 写入 `fmu_model/src/models/TorqueDistModel/resources/configs/ptu_sany_2source.xml`，重建 `fmu_TorqueDistModel`、`fmu_RsimVehicle_SANY`、`fmu_ExperimentModule` 和 `ExperimentModule_test`。最终验证批次为 `runs/sany_startgain_t7_final_launch_shape_c_20260609_143846`，报告在 `runs/sany_startgain_t7_final_launch_shape_c_20260609_143846/launch_shape_c/experiment_image_report.md`。32/32 段 return code 为 0，每段 7 张图；最终 all 组 `early_abs_mean=0.209041948566`、`shift_delay_abs_mean=0.90099009901`，相对 baseline 的 `0.217104033818` 和 `0.938910891089` 有改善；`vmax_abs_mean=0.710380300149`，相对 baseline `0.695369059986` 略有增加，属于当前起步响应优化的可接受代价。
- (Agent 2026-06-09) T7 收口测试：最终批次后再次执行 `/tmp/rsim_dataloger_table_build/datalogger_test` 和 `/tmp/rsim_torquedist_t6_build/TorqueDistModel_test`，均通过。前者覆盖标量 logger、CSV 序列化、FMI XML 解析和 FMI3 数组表格反序列化；后者覆盖 direct、throttle、regen、数组长度错误和 `PTU_StartGain` 注入路径。
