# 子 FMU Config = modelDescription（2026-06-02）

## 目标

`Module@config` 指向的文件与 FMU 根目录 `modelDescription.xml` **同格式**（完整 `fmiModelDescription`），而非旧的 `<Config kind="...">` 参数表。

同一 `.so`（如 `CSV_fmuModel`）可通过不同 config 切换：

- 不同 CSV 路径与插值策略（`start` 初值）
- 不同 I/O 变量集合（CarSim 式场景变体）

## 机制

1. **registerChild**：`resolveChildSchemaXmlPath()` → 显式 config 或 `resources/configs/default.xml` 或 FMU 根 `modelDescription.xml`
2. **loadFromXmlAsModule(configPath, alias)**：组合图变量注册（带 `alias_` 前缀）
3. **instantiate 前**：`FmiSchemaPathOverride` 设置环境变量 `RSIM_FMU_SCHEMA_PATH` → 子 `.so` 内 `fmiInstantiate` 的 `loadSchemaFromXml` 加载 **config**（跨 DSO 可见，避免 thread_local 失效）
4. **删除** `applyConfigToChild` / `parseConfigEntries`（Integration + Orchestrator）

实现：`RSimFmuRuntime/include/ModuleSchemaResolver.hpp`

## 配置示例

`CSV_fmuModel/resources/configs/csv_sany_smoke.xml`：完整 FMI MD，`CSV_Path start="sany_dual_motor_smoke.csv"`，仅声明 SANY smoke 所需输出列。

## 验证

```bash
cmake --build fmu_model/build_experiment --target ExperimentModule_test -j4
RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build_experiment/ExperimentModule_test
```

## 讨论

- (2026-06-02) 自 P0a `<Parameter>` 注入改为 schema 替换；Host/Experiment 侧 Annotations 仍用 `com.rsim.integration.config`。
