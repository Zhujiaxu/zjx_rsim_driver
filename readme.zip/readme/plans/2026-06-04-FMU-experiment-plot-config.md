# ExperimentModule 实验作图配置与后处理

- 来源 issue: 用户请求（2026-06-04，ExperimentModule 实验作图）
- 创建日期: 2026-06-04
- 负责: agent
- 状态: 🟠 进行中

## 改进目标

### 目标状态
- `ExperimentModule` 继续作为实验整图包装：每步 doStep 负责推进子 FMU、同步 Self 监控变量、按配置计算误差派生列并记录作图所需数据，不在实时步内执行 Python 或生成图片。
- 作图需求写在 `ExperimentModule/modelDescription.xml` 或其 `resources/configs/*.xml` 变体的 `Annotations` 中，与现有 `com.rsim.integration.config` 实验图配置放在同一实验描述文件内。
- 支持首批两类图：
  - 时间轴对比图：横坐标为时间，支持两个或多个变量序列叠加，例如 `REF_Vx` vs `Vx`、`REF_GearStat` vs `GB_GearStat`，并可把每步计算出的绝对误差/相对误差作为普通序列一起画。
  - XY/轨迹图：横坐标不是时间，支持参考轨迹与仿真轨迹叠加，例如 `REF_Xo,REF_Yo` vs `Xo,Yo`。
- `Plots` 配置同时决定哪些 ref/actual 变量需要计算误差，以及误差写入哪个已声明的 Self 变量；例如 `REF_Vx` 与 `Vx` 计算到 `Vx_AbsError` / `Vx_RelError`。
- 仿真结束后由回调/后处理入口读取实验输出目录里的 CSV，调用 Python 生成 PNG 与 `plot_index.json`，复用现有 `tools/postprocess` 的 renderer 结构。

### 约束
- 不把 matplotlib/Python 调用放入 `DoStep()`；实时步内只做轻量数值派生计算和数据采集，避免仿真耗时和外部解释器影响 FMI doStep。
- 不把作图配置混入 `<Connections>`；连接图仍只描述模块间数据流，作图配置只描述“哪些列如何画”。
- 不破坏现有 `com.rsim.integration.config` 对 `<Submodules>` / `<Connections>` 的解析行为；未知作图标签必须可被旧逻辑忽略或单独解析。
- 首批只支持数值列；缺列时后处理要报出清晰错误，不做静默空图。
- 误差输出列必须在父 FMU `ModelVariables` 中声明为普通 Float64 Self 变量；配置只绑定计算关系，不隐式创造 FMI 变量或 valueReference。
- 相对误差除零策略必须固定：默认 `abs(ref) <= eps` 时记为 `0` 或 NaN 二选一，先采用 `0` 并在配置中允许 `eps` 覆盖。
- CSV 列名以 `VehicleLogger` / `CSVSerializer` 实际输出列为准，优先使用 `Self` 变量名（如 `Vx`、`REF_Vx`），必要时允许完整 logger key（如 `vehicle_Vx`、`csv_driver_REF_Vx`）。`<Plots>` 不筛选 CSV 列；除非 Host 显式设置 `CSV_StoredKey`，否则保留 CSVSerializer 原有全量输出行为。

### 成功指标
- 在 `ExperimentModule` 默认 SANY 实车实验配置中声明至少 3 张图：速度对比、挡位/传动相关对比、XY 轨迹对比；速度对比中包含每步计算的 `Vx_AbsError` / `Vx_RelError`。
- 一次 `ExperimentModule_test` 或等价实验运行后，输出目录包含实验 CSV、作图配置副本、`plots/*.png`、`plot_index.json`。
- 实验 CSV 中能看到由 `ExperimentModule` 每步写入的误差列，且误差列与 `abs(actual-ref)` / `abs(actual-ref)/abs(ref)` 一致。
- 后处理命令能直接对已有 CSV 重跑出图，便于只改图配置不重跑仿真。
- 现有 `IntergrationFmu` / `ExperimentModule` 构建通过；现有 `RegressionValidatorModel` 后处理能力不被破坏。

## 背景 / 现状

- `ExperimentModule` 当前继承 `IntergrationFmu`，`DoStep()` 中先写 `Sim_time` 到 `VehicleLogger`，再调用 `IntergrationFmu::DoStep(dt)`；调用父类返回后，Self 监控变量已经从子模块同步回来，因此这个位置适合按配置计算 `ref`/`actual` 的每步误差派生列，但不适合执行图像渲染。
- `ExperimentModule/modelDescription.xml` 已经在 `Annotations type="com.rsim.integration.config"` 中声明子模块与连接，默认实验会把 CSV 参考量和 DUT 输出回写到 Self，例如 `REF_Vx`、`Vx`、`REF_Xo`、`Xo`、`REF_Yo`、`Yo`、`REF_GearStat`、`GB_GearStat`。
- `dataloger/include/CsvSerializer.hpp` 已支持用 `CSV_FolderPath`、`CSV_FileName`、`CSV_StoredKey` 控制输出 CSV；因此作图列的采集可以落在 CSV 输出层，不需要每张图单独保存一份数据。
- `tools/postprocess` 已有 XML `<Plots>` 解析和 Python renderer：
  - `TimeSeries`：按 `compare.csv` 和 `pair_index.csv` 做时间序列值/误差图。
  - `Trajectory`：按指定 x/y 列画轨迹。
- `RegressionValidatorModel` 已会写 `metrics.json`、`pair_index.csv`、`validator_config.xml`，但 ExperimentModule 默认实验当前没有统一的“实验 CSV -> run_dir -> plots”的落盘协议。

## 方案判断

- 用户提出“在 `ExperimentModule : public IntergrationFmu` 里实现，每步 step 时根据 plot 配置计算 ref/actual 的绝对误差和相对误差，配置放在 `<Annotations><Annotation type="com.rsim.integration.config">`，结束后调用 resources 中 Python 模块读取实验目录 CSV 并出图”的方向可实现，且与当前架构匹配。
- 需要调整的点：
  - `DoStep()` 可以在 `IntergrationFmu::DoStep(dt)` 成功之后计算轻量误差列，并写入 `VehicleLogger`；Python 作图放在 `Terminate()`、测试 harness、orchestrator run 结束钩子或独立 CLI 中。
  - 作图配置可以放在同一个 `Annotation` 里，但应使用独立子块，例如 `<Plots>`，不要扩展 `<Connection>` 语义。
  - 不应让 Python 重新决定误差语义；`Plots` 中声明的误差派生列由 C++ 每步计算并进入 CSV，Python 只按配置读取列并画图。
  - 现有 `tools/postprocess` 已有 `<Plots>` 协议，应优先泛化/复用，而不是新建另一套作图 XML。

## 拟定 XML 形态

```xml
<Annotation type="com.rsim.integration.config">
  <Submodules>
    <Module role="driver" type="CSV_fmuModel" alias="csv_driver"
            config="csv_sany_realdata_fixed_throttle.xml"/>
    <Module role="dut" type="RsimVehicle_SANY" alias="vehicle"/>
  </Submodules>
  <Connections>
    ...
  </Connections>
  <Plots>
    <TimeSeries id="speed" x="Sim_time" title="Speed"
                series="REF_Vx:reference,Vx:simulation,Vx_AbsError:absolute error,Vx_RelError:relative error">
      <Compare ref="REF_Vx" actual="Vx"
               absError="Vx_AbsError" relError="Vx_RelError" relEps="1e-6"/>
    </TimeSeries>
    <TimeSeries id="gear" x="Sim_time" title="Gear"
                series="REF_GearStat:reference,GB_GearStat:simulation"/>
    <Trajectory id="xy" title="Trajectory"
                expected="REF_Xo,REF_Yo" actual="Xo,Yo"/>
  </Plots>
</Annotation>
```

说明：
- `Plots/TimeSeries@series` 直接引用 CSV 列，比当前 `pair_index.csv` 间接 pair 协议更适合 ExperimentModule 的“直观对比图”。
- `Compare@ref` / `Compare@actual` 声明每步读取哪两个 logger 变量；`absError` / `relError` 声明写到哪个已存在的 Self 输出变量。若只需要绝对误差，可只写 `absError`；若只需要相对误差，可只写 `relError`。
- 误差计算时机：`ExperimentModule::DoStep(dt)` 先写 `Sim_time`，再执行 `IntergrationFmu::DoStep(dt)`，成功后执行 `computeConfiguredPlotDerivedValues()`，把误差列写入 `VehicleLogger`。随后 CSV serializer 的 snapshot 会包含这些派生列。
- `Trajectory` 建议同时兼容现有 renderer 的 `x/y/expected` 写法与新写法 `expected/actual`，减少重复工具。

## 任务列表

- [x] T1: 定义 ExperimentModule 作图与派生列 schema —— 明确 `<Plots>`、`<TimeSeries>`、`<Compare>`、`<Trajectory>` 字段、列名解析规则、缺列错误策略、相对误差除零策略，并写入 `ExperimentModule/README.md`。
- [x] T2: 在 ExperimentModule 内部增加局部 PlotConfig / CompareSpec 解析 —— 暂不改 dataloger/GraphManager；`ExperimentModule` 从当前父 `modelDescription.xml` 提取 `<Plots>` 与 `<Compare>`。
- [x] T3: 在 ExperimentModule doStep 后半段接入误差计算 —— `IntergrationFmu::DoStep(dt)` 成功后遍历 CompareSpec，从 `VehicleLogger` 读取 ref/actual，计算 `abs(actual-ref)` 和 `abs(actual-ref)/max(abs(ref), eps)`，写入配置指定的 Self 变量/logger key。
- [x] T4: 在 ExperimentModule 终止或测试结束路径接入实验输出协议 —— 确定 run_dir、实验 CSV 路径和作图配置副本；CSV 列筛选继续由 Host 显式 `CSV_StoredKey` 控制，不由 `<Plots>` 自动写入。
- [x] T5: 将 Python 作图模块放入 ExperimentModule resources 或复用 root `tools/postprocess` —— 支持直接读取 ExperimentModule CSV 与 `<Plots>`，允许无 `metrics.json` / `pair_index.csv` 的纯作图模式，并新增 `TimeSeries@series`、`Compare` 派生列展示与 `Trajectory@actual`。
- [x] T6: 给默认 SANY 实车实验配置补 Self 误差变量和作图声明 —— 至少包含速度对比（含 `Vx_AbsError` / `Vx_RelError`）、挡位/传动相关对比、XY 轨迹图。
- [ ] T7: 增加最小回归/烟测 —— 用一份小 CSV fixture 跑 doStep 派生列计算和 Python 后处理，断言误差数值与 PNG / `plot_index.json`。

## 验证项

- [x] V1: 跑 `cmake --build fmu_model/build -j2`，期望 ExperimentModule 编译通过。
- [ ] V2: 跑单元/烟测覆盖 `Compare ref="REF_Vx" actual="Vx" absError="Vx_AbsError" relError="Vx_RelError"`，输入 `REF_Vx=10`、`Vx=12`，期望 `Vx_AbsError=2`、`Vx_RelError=0.2`。
- [x] V3: 跑 `python -m tools.postprocess --csv <实验CSV> --validator-config <含Plots的XML> --out <run_dir>` 或 ExperimentModule resources 中等价 Python 入口，期望生成 `plots/timeseries_speed*.png`、`plots/timeseries_gear*.png`、`plots/trajectory_xy.png`、`plot_index.json`。
- [x] V4: 跑 `RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build/ExperimentModule_test` 或等价可用环境，期望 CSV 中包含每步误差派生列；若物理 leaf FMU 环境仍失败，则用已有 CSV 走 V3 验证作图链路。
- [ ] V5: 跑现有 `python -m tools.postprocess runs/jd_smoke_001`，期望 RegressionValidatorModel 旧 `<Plots>` 配置仍能出图。

## 风险 / 已知坑

- `CSVSerializer` 当前输出路径和最终 CSV 文件名带时间戳；自动回调需要可靠拿到实际生成文件路径，否则先以独立 CLI 作为第一阶段。
- `FmiXmlSchemaDeserializer` 当前 XML 解析是轻量字符串解析；新增 `<Plots>` 时要避免被 `<Connections>` 解析误伤，必要时只提取完整 `<Plots>` XML 文本，细节解析交给 Python 或单独 C++ helper。
- 如果误差输出变量没有在 `ModelVariables` 中声明，Host 侧不能通过 FMI Get 读取；实现时应在初始化阶段校验并报错，而不是悄悄写一个只存在于 `VehicleLogger` 的 key。
- 对挡位这类离散量不建议默认算相对误差；`Compare` 需要显式声明 `absError` / `relError`，没有声明就只画原始序列。
- 默认实验目前可能仍受外部 `RsimVehicle_SANY_Physics` 环境/二进制影响，端到端验证可能被物理 leaf instantiate 阻塞；作图链路必须能用已有 CSV 离线验证。
- 如果后续要支持多 Y 轴、散点、误差带、单位换算，先扩展 Python renderer，不要扩展 `DoStep()`。

## 讨论

- (Agent 2026-06-04) 阅读 `readme/`、`ExperimentModule` README、默认 `modelDescription.xml`、`CsvSerializer` 和 `tools/postprocess` 后起草本 plan。判断用户方案总体方向合理，但实时 C++ 层只做数据采集和输出配置，Python 作图应放在仿真结束后的后处理链路；配置建议作为 `com.rsim.integration.config` 下的 `<Plots>` 独立子块。
- (User 2026-06-04) 补充要求：`DoStep()` 每步根据 `Plots` 中的配置读取 ref/actual，计算绝对误差和相对误差，并写入 XML 中已正常声明的变量；resources 中的 Python 模块在仿真后读取 CSV 和 `Plots` 配置出图。
- (Agent 2026-06-04) 更新 plan：确认可实现，新增 `<Compare>` 派生列语义；误差计算放在 `IntergrationFmu::DoStep(dt)` 成功之后，Python 仅渲染 CSV 中已经产生的原始列和误差列。
- (Agent 2026-06-04) 按用户要求把 `<Plots>` 解析暂时收敛在 `ExperimentModule` 内部，未改 `GraphManager/FmiXmlSchemaDeserializer`。`ExperimentModule.hpp` 已实现局部 `<ExperimentOutputs>` / `<Compare>` 解析、`CSV_StoredKey` 默认写入、doStep 后误差计算；默认父 MD 与 SANY 实验 config 已增加 `Vx_AbsError` / `Vx_RelError` 和三类图配置；`resources/tools/experiment_plot.py` 已能从 CSV + MD 生成 3 张图。验证：`cmake --build fmu_model/build -j2` 通过；临时 CSV 跑 `experiment_plot.py` 生成 `timeseries_speed.png`、`timeseries_gear.png`、`trajectory_xy.png`。
- (Agent 2026-06-04) 端到端验证通过：`RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build/ExperimentModule_test` 完成 50s smoke，生成 `RSimDataRecord/ExperimentModule_Test_20260604_144327.csv`，表头包含 `Sim_time,REF_Vx,Vx,Vx_AbsError,Vx_RelError,REF_GearStat,GB_GearStat,REF_Xo,REF_Yo,Xo,Yo`；前几行 `REF_Vx=0` 时相对误差按策略写 `0`。随后用 build resources 脚本对真实 CSV 出图，生成 `RSimDataRecord/ExperimentModule_Test_20260604_144327_plots/plots/{timeseries_speed,trajectory_xy,timeseries_gear}.png`。
- (User 2026-06-04) 指出作图数据直接使用原先 `ModelVariables` 声明即可，不需要单独放在扩充/筛选列中。
- (Agent 2026-06-04) 调整边界：删除 `<ExperimentOutputs>` 和 `ExperimentModule` 自动写 `CSV_StoredKey` 的逻辑；`<Plots>` 只负责声明图和误差计算关系，不负责筛选 CSV 输出列。CSV 默认恢复 `CSVSerializer` 原有行为；如需过滤列，由 Host 显式设置 `CSV_StoredKey`。
- (User 2026-06-04) 反馈 `ExperimentModule_Test_20260604_152408_plots` 中速度和轨迹图不理想。
- (Agent 2026-06-04) 修正 `resources/tools/experiment_plot.py`：TimeSeries 改为按同一 CSV 行对齐数据，并将普通值 / 绝对误差 / 相对误差自动分面，避免 `Vx_RelError` 在低参考速度处的尖峰压扁速度曲线；Trajectory 增加默认 `align="auto"`，检测到参考局部坐标与车辆全局坐标存在固定偏移时按首点原点对齐。已用 `RSimDataRecord/ExperimentModule_Test_20260604_152408.csv` 覆盖重生成用户查看目录，并用最新 `ExperimentModule_Test_20260604_170803.csv` 生成 `ExperimentModule_Test_20260604_170803_plots/`；误差列数值校验最大差异约 `1e-9` 以内。
- (Agent 2026-06-05) 接入统一实验输出目录协议：`ExperimentModule::InitializationMode()` 在子 FMU 初始化前生成 `RSimDataRecord/<CSV_FileName>_<timestamp>`，写入 `CSV_FolderPath` / `CSV_RunTimestamp`；`IntergrationFmu` 在子 FMU `exitInitializationMode` 前把这些 CSV 输出上下文递归写入声明了同名 String 参数的子模块；`CSVSerializer` 支持复用 `CSV_RunTimestamp` 并递归创建目录。为 `CSV_fmuModel` configs、`PIDControllerModel`、`RsimVehicle_FMI3` 补充 CSV 输出上下文参数。验证 hello 车辆日志回放：`RSimDataRecord/ExperimentModule_Test_20260605_111127/` 下包含 `ExperimentModule_Test_20260605_111129.csv`、`csv_driver_20260605_111127.csv`、`PID_1_20260605_111127.csv`、`VehicleData_20260605_111129.csv`、`RSimVehicleData_20260605_111127.csv`，并用 `experiment_plot.py --out RSimDataRecord/ExperimentModule_Test_20260605_111127` 生成 6 张图到 `plots/`；测试仍因 hello 旧断言 `gearbox torque response too small: 0` 返回 8。
- (Agent 2026-06-05) 切回 SANY 实车固定油门实验并补齐 SANY wrapper 递归输出上下文：`RsimVehicle_SANY` 增加 `CSV_RunTimestamp`，`DualMotorGearboxModel`、`TorqueDistModel` 和 `ptu_sany_2source.xml` 增加 `CSV_FolderPath` / `CSV_RunTimestamp`，重建 `RsimVehicle_SANY`、`DualMotorGearboxModel`、`TorqueDistModel` FMU layout。验证 `RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build/ExperimentModule_test` 返回 0，输出集中在 `RSimDataRecord/ExperimentModule_Test_20260605_113244/`：包含 parent、csv_driver、ptu、gearbox、VehicleData、RSimVehicleData CSV；`experiment_plot.py --out` 同目录生成 8 张图到一层 `plots/`。
- (Agent 2026-06-05) 增加最外层 XML 参数 `Experiment_RunName` 控制 run folder 名称种子；`ExperimentModule` 优先使用该参数，自动 trim、去掉末尾 `.csv`，并把 `/` / `\` 替换为 `_` 后再拼接时间戳。默认 SANY 实验将 `Experiment_RunName` 设为 `（可用）2026-04-14,18_52_17.297.csv`。验证 SANY 实验返回 0，输出目录变为 `RSimDataRecord/（可用）2026-04-14,18_52_17.297_20260605_114300/`，同目录包含 parent、csv_driver、ptu、gearbox、VehicleData、RSimVehicleData CSV 和 8 张 `plots/*.png`。
- (Agent 2026-06-05) 将 run folder 名称默认改为从 CSV 子 config 推导：当最外层 `Experiment_RunName` 为空时，`ExperimentModule` 解析父 MD 中 `CSV_fmuModel` 的 `Module@config`，读取该子 config 的 `CSV_Path@start` basename，去掉 `.csv` 后作为 run folder 名称种子；`Experiment_RunName` 仍保留为最外层覆盖入口。`ExperimentModuleTest` runner 现在在 `fmi3FreeInstance()` 关闭 CSV writer 后自动调用 `experiment_plot.py --csv <run_dir>/ExperimentModule_Test_*.csv --config <fmuRoot>/modelDescription.xml --out <run_dir>`，FMU 模型内部不直接调用 Python。验证 SANY 返回 0，自动输出 `RSimDataRecord/（可用）2026-04-14,18_52_17.297_20260605_115317/`，包含所有 CSV、`plot_index.json` 和 8 张 `plots/*.png`。
- (Agent 2026-06-05) 按用户要求清理过时 config：源码和 build 的 `resources/configs` 现在只保留 SANY 实验、hello 实验和 SANY 依赖的 `ptu_sany_2source.xml`。删除旧 smoke、电机扭矩 snippet、direct motor、通用 PTU 1/2/3/4 source 和 RegressionValidator 旧 config；更新 CSV_fmuModel、ExperimentModule、TorqueDistModel、RsimVehicle_SANY README 中的旧 config 引用。验证剩余 XML 全部可解析，`ExperimentModule_test` SANY 默认返回 0 并自动生成 8 张图。
- (Agent 2026-06-05) 将 SANY 默认实验时长改为 300s：`ExperimentModule/modelDescription.xml` 与 `resources/configs/sany_realdata_fixed_throttle_experiment.xml` 的 `Sim_stopTime start` 均为 `300.0`，并同步到 build。验证 `ExperimentModule_test` 返回 0，自动出图完成；run 目录 `RSimDataRecord/（可用）2026-04-14,18_52_17.297_20260605_120427/` 包含 30030 行 parent CSV、ptu/gearbox/vehicle/csv_driver CSV 和 8 张图，峰值 `GB_AV_Trans=3239.47 rpm`、`GB_M_Trans=12250.7 Nm`。
