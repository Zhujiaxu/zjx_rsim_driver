# processes/ — 功能实现流程说明

本目录收录「某条用户可见功能在代码里如何走通」的流程文档，偏重**调用顺序与时间语义**，与 `plans/`（待做）、`investigations/`（故障诊断）、`issues/`（缺陷登记）区分开。

命名建议：`[<scope>]<主题>.md`，例如 `[ORC]manual-step-flow.md`。与源码强绑定的条目请在正文顶部写明**对齐的源码树**（本仓 `basic_model/orchestrator/` 或与 DVM 同构的 `dynamic_vehicle_module/rsim_orchestrator/`）。

## 条目索引

| 文档 | 功能 | 源码基准 |
|------|------|-----------|
| [orchestrator-manual-step-flow.md](orchestrator-manual-step-flow.md) | 编排器「手动步进」（`StepCommand` → `doStep`）全链路 | `basic_model/orchestrator`、`basic_model/TimeManager` |

DVM 流程文档只在 `../../dynamic_vehicle_module/readme/processes/` 维护，包括配置读取、异步 run、日志链路、传感器 tick、FMI2/FMI3 模型库要求、性能调查入口等。root 侧只保留 basic_model standalone 流程。

## 维护约定

1. **流程可变**：实现改动后应及时更新对应流程文档，或在文档首段注明过期日期。
2. **不写重复百科全书**：与时间层总览重复的图仍引用 `../orchestrator/README.md`，此处只补足「这一条路径」的细节。
3. **与 authoritative 文档冲突时**：仍以各子目录根 README 与工作区顶层说明为准。
