# [ORC] 手动仿真步进（`StepCommand` → `step` → `doStep`）流程

**对齐源码**：本文以仓库内 `basic_model/orchestrator/` 与 `basic_model/TimeManager/` 为准。若你在 `dynamic_vehicle_module` 中使用 **内嵌拷贝** `rsim_orchestrator/`，链路名称与类名一致，个别错误处理可能与主线略有差别，以该目录下源码为准。

---

## 一、术语先理清（读代码前必读）

编排里同时出现多层「步长」和两处「仿真时间」，先区分概念再跟调用栈。

### 1. 宏步与定步切片

| 名称 | 符号/来源 | 含义 |
|------|-----------|------|
| **手动宏步时长** | `d`（`StepCommand` 解析后传给 `OrchestratorRunner::step(d)`） | 一次命令/一次 `step(dt)` 希望整场仿真**总共**向前推进多长。可由命令自带正 `dt`，否则退回 `VehicleLogger` 里的 `Orch_FixedStep`（`readOrchFixedStep()`）。 |
| **定步 / 切片步长** | `fixedStep`、`h` | 从配置读的 `Orch_FixedStep`（或退化场景下等于剩余宏步）。`tickSimulationStep` 保证每个子片 `h` ≤ `fixedStep`。 |
| **TimeManager 子 tick** | `tmgr_->tick(h)` | 每个子片调用一次；内部会触发一次 `sink_->onAdvance(h)` → `onTimeAdvance(h)`。 |

因此：**一个宏步可能被切成多次 `tick(h)`**，子 FMU 的 `doStep` 粒度与 **`h`** 一致，而不是一定只等于外层 `d`。

### 2. 通信起点 `tComm` 与时间轴

在 `OrchestratorRunner::onTimeAdvance` 内（节选逻辑）：

1. **`tComm = VehicleLogger.currentTime().tR`**（在调用 `advance` **之前**取快照）——作为本片的 **FMI 通信起始时刻**传给 `FMURuntime::step(tComm, dt, …)` / `FmuOrchestratorCore::step`。  
2. **`VehicleLogger.advance(dt)`**：把编排侧「业务日志时钟」向前走 `dt`。  
3. **`runtime_.step(tComm, dt, …)`**：在核心里用「从 `tComm` 起步、步长 `dt`」推子 FMU；成功后 `currentTime_` 更新为 `tComm + dt`（与其它地方约定一致）。

**注意**：若在 `advance` 之后、`step` **失败**，可能出现 `VehicleLogger.tR` 已前进而 `core.currentTime()` 未前进的不一致（代码里会对明显漂移打告警）。这需要从「谁先改时钟」去理解，不代表 `tComm` 取错了。

### 3. 「TimeManager 的时钟」与「编排回调」

- `TimeManager` 内部维护自己的 `clock_.tR`，在每次 `advanceBy` 末尾 **`clock_.tR += dt`**。  
- 编排侧把 **推进一帧仿真**绑定在 `sink_->onAdvance(dt)` 上（`FunctionTimeSink` → `OrchestratorRunner::onTimeAdvance(dt)`）。  
- **它不是 FMU API**：`tick`/`advanceBy` 只负责“该回调了”；真正 `doStep` 只在 `onTimeAdvance` → `FMURuntime::step` 之后发生。

### 4. 结果如何回到命令层

- `onTimeAdvance` 末尾在锁内更新 **`lastAdvanceOk_`**、`**lastAdvanceMessage_**`。  
- `OrchestratorRunner::step(d)` 在 `tickSimulationStep(d)` 之后读 **`lastAdvanceOk_`** 作为返回值。  
- **`StepCommand` 分发**再根据该布尔值写日志、`setOkText` / `setFail`，并把 **`lastAdvanceMessage_`**透传给调用方错误串。

---

## 二、总览序列（Mermaid）

```mermaid
sequenceDiagram
  participant Bus as RuntimeCommand（StepCommand）
  participant OR as OrchestratorRunner
  participant TM as TimeManager
  participant Sink as FunctionTimeSink
  participant RT as FMURuntime
  participant Core as FmuOrchestratorCore
  participant FMU as FMI3Instance::doStep

  Bus->>OR: dispatch StepCommand<br/>d = cmd.dt>0 ? cmd.dt : readOrchFixedStep()
  OR->>OR: step(d)
  OR->>OR: tickSimulationStep(d)
  loop accumulated < d（步长切片 h）
    OR->>TM: tick(h)
    TM->>TM: tickInternal → advanceBy(h)
    TM->>Sink: onAdvance(h)
    Sink->>OR: onTimeAdvance(h)
    OR->>OR: latchInputs；tComm=VehicleLogger.tR<br/>advance(h)；step(tComm,h)
    OR->>RT: step(...)
    RT->>Core: step(...)
    Core->>Core: 按调度图 stepOne→doStep
    Core->>FMU: doStep(...)
    OR->>OR: lastAdvanceOk_/Message
    alt 本片失败
      OR-->>OR: tick 循环提前结束
    end
  end
  OR-->>Bus: ok / fail + message
```

更粗的时间层关系仍见 `basic_model/orchestrator/README.md` 中「时间层顺序图」一节。

---

## 三、分阶段详解（与当前源码对应）

### 阶段 A —— 命令入口：`StepCommand`

**做什么**：只做「算出本次宏步 `d`、调用成员 `step(d)`、把结果编成回复」，**不解 FMU 变量**。

- 若有正 `stepCmd->dt`，`d = stepCmd->dt`；否则 **`d = readOrchFixedStep()`**（从 `VehicleLogger` 读 `Orch_FixedStep`）。  
- `ok = step(d)`；据此写结构化日志，`setFail` 时带上 `lastAdvanceMessage_`（若为空则退回 `"manual step failed"`）。

源码位置：`OrchestratorRunner::dispatchRuntimeCommand` 中对 `StepCommand` 的分支。

```817:830:AccumulatedExperience/basic_model/orchestrator/src/OrchestratorRunner.cpp
  if (const auto* stepCmd = std::get_if<StepCommand>(&cmd.payload)) {
    double d = stepCmd->dt > 0.0 ? stepCmd->dt : readOrchFixedStep();
    const bool ok = step(d);
    logBuffer_.pushMessage(runtime_.state(), ok ? FMIOK : FMIError,
                           ok ? "manual step ok" :
                                (lastAdvanceMessage_.empty() ? "manual step failed" : lastAdvanceMessage_));
    flushLogBuffer();
    if (ok) setOkText("ok step");
    else {
      const std::string er = lastAdvanceMessage_.empty() ? "manual step failed" : lastAdvanceMessage_;
      setFail(er);
      if (errorMessage) *errorMessage = er;
    }
    return ok;
  }
```

### 阶段 B —— `OrchestratorRunner::step(double dt)`

**做什么**：校验 `tmgr_` 与 `dt>0`，然后调用 **`tickSimulationStep(dt)`**；最后用锁读取 **`lastAdvanceOk_`** 作为返回值（该标志由各次 `onTimeAdvance` 写入）。

```660:673:AccumulatedExperience/basic_model/orchestrator/src/OrchestratorRunner.cpp
bool OrchestratorRunner::step(double dt) {
  if (!tmgr_) {
    logBuffer_.pushMessage(runtime_.state(), FMIError, "TimeManager not initialized");
    flushLogBuffer();
    return false;
  }
  if (dt <= 0.0) {
    logBuffer_.pushMessage(runtime_.state(), FMIWarning, "dt must be > 0");
    flushLogBuffer();
    return false;
  }
  tickSimulationStep(dt);
  std::lock_guard<std::mutex> lk(advanceMu_);
  return lastAdvanceOk_;
}
```

### 阶段 C —— `tickSimulationStep(double dt)`：按定步切段

**做什么**：

1. 读 **`fixedStep = readOrchFixedStep()`**（非法时退化用本次宏步 `dt`）。  
2. **`RuntimePhase::BeforeStep`** → 循环：每次 `remaining = dt - accumulated`，**`h = min(fixedStep, remaining)`**，调 **`tmgr_->tick(h)`**。  
3. 每片之后读 **`lastAdvanceOk_`**；若为 `false`，相位回到 **Idle**，**提前 return**（余下切片不再执行）。  
4. 全部成功后 → **`AfterStep`** →（可选实时睡眠）→ **Idle**。

```622:658:AccumulatedExperience/basic_model/orchestrator/src/OrchestratorRunner.cpp
void OrchestratorRunner::tickSimulationStep(double dt) {
  if (!tmgr_ || dt <= 0.0) return;
  // ...
  double accumulated = 0.0;
  while (accumulated + kTimeEps < dt) {
    const double remaining = dt - accumulated;
    const double h = std::min(fixedStep, remaining);
    tmgr_->tick(h);
    {
      std::lock_guard<std::mutex> lk(advanceMu_);
      if (!lastAdvanceOk_) {
        runtimePhase_.store(RuntimePhase::Idle, std::memory_order_relaxed);
        return;
      }
    }
    accumulated += h;
  }
  runtimePhase_.store(RuntimePhase::AfterStep, std::memory_order_relaxed);
  // ...
  runtimePhase_.store(RuntimePhase::Idle, std::memory_order_relaxed);
}
```

### 阶段 D —— `TimeManager::tick` → `advanceBy` → `sink_->onAdvance`

**做什么**：同步路径下，`tick(dt)`（`dt>0`）持 `tickMutex_` 调用 `tickInternal(dt)`；在 **`AfterAdvance`** 策略下会先 **`advanceBy(dtSim)`**：先 **`sink_->onAdvance(dt)`**，再 **`clock_.tR += dt`**。

```194:198:AccumulatedExperience/basic_model/TimeManager/include/TimeManager/TimeManager.hpp
  void tick(double dt) {
    if (dt <= 0.0) return;
    std::lock_guard<std::mutex> tickLock(tickMutex_);
    tickInternal(dt);
  }
```

```469:476:AccumulatedExperience/basic_model/TimeManager/include/TimeManager/TimeManager.hpp
  void advanceBy(double dt) {
    if (dt <= 0.0) return;

    sink_->onAdvance(dt);
    std::lock_guard<std::mutex> lk(m_);
    clock_.tR += dt;
    clock_.tI = 0;
  }
```

若配置为 **`SplitAdvance`**，同一宏观 `tick` 内可能对 `advanceBy` 切段多次（事件插队）；编排仍通过同一个 `sink_` 多次进入 `onTimeAdvance`，本篇不展开事件堆细节。

### 阶段 E —— `FunctionTimeSink` 与 `onTimeAdvance`

bootstrap 末尾 **`initTimeManagerAfterBootstrap`** 里：把 **`adv` 设为** `[this](double dt) { onTimeAdvance(dt); }`，交给 **`FunctionTimeSink`**。

```252:287:AccumulatedExperience/basic_model/orchestrator/src/OrchestratorRunner.cpp
void OrchestratorRunner::initTimeManagerAfterBootstrap() {
  // ...
  auto adv = [this](double dt) { onTimeAdvance(dt); };
  auto trig = []() { VehicleLogger.triggerEvent(); };

  timeSink_ = std::make_shared<time_manager::FunctionTimeSink>(std::move(adv),
                                                               std::move(trig));
  // ...
  tmgr_ = std::make_shared<time_manager::TimeManager>(timeSink_, tcfg);
  // ...
  runtime_.setTimeManager(tmgr_, timeSink_);
}
```

因而：**每次 `tmgr_->tick(h)` → `onAdvance(h)` → `OrchestratorRunner::onTimeAdvance(h)`**，其中 `h` 即本节「定步切片」的长度。

### 阶段 F —— `onTimeAdvance`：`tComm`、`VehicleLogger`、核心 `step`

单片逻辑要点：

1. `latchInputsForStep`。  
2. **`tComm = VehicleLogger.currentTime().tR`（advance 之前）**。  
3. **`VehicleLogger.advance(dt)`**；并按当前约定 `log("Time", tComm)`。  
4. **`runtime_.step(tComm, dt, &stepError)`**——此处才进入 FMU。  
5. 发布状态、可选校时告警；最后在锁内 **`lastAdvanceOk_ = stepOk`**，`lastAdvanceMessage_ = stepError`；递增 **`stepIndex_`**。

```289:354:AccumulatedExperience/basic_model/orchestrator/src/OrchestratorRunner.cpp
void OrchestratorRunner::onTimeAdvance(double dt) {
  if (dt <= 0.0) return;

  runtimePhase_.store(RuntimePhase::Stepping, std::memory_order_relaxed);
  logBuffer_.pushMessage(runtime_.state(), FMIOK, "enter stepping");

  runtime_.dataBus().latchInputsForStep();

  const double tComm = VehicleLogger.currentTime().tR;

  VehicleLogger.advance(dt);
  VehicleLogger.log("Time", tComm);

  std::string stepError;
  const bool stepOk = runtime_.step(tComm, dt, &stepError);
  // ... 时间与日志 ...
  {
    std::lock_guard<std::mutex> lk(advanceMu_);
    lastAdvanceOk_ = stepOk;
    lastAdvanceMessage_ = stepError;
  }

  stepIndex_++;
  // ...
}
```

### 阶段 G —— `FMURuntime::step` → `FmuOrchestratorCore::step` → `stepOne` → `doStep`

- **`FMURuntime::step`** 直接转调 **`core_.step`**。  
- **`FmuOrchestratorCore::step`**：`state_ == FMIStepModeState`，按 **`GraphManager` 调度组**遍历节点；对每个 **有效子节点索引 `childIdx`** 调 **`stepOne(childIdx, currentTimeSec, dt)`**。  
  - 外层循环变量是图中的 **`nodeIdx`**；**`childIdx = nodeIndexToChildIndex_[nodeIdx]`** 是按「图节点 → 子实例槽位」映射，索引名不同是刻意的，并非笔误。  
- **`stepOne`**：`transferIncomingEdgesToChild`，然后 **`c.instance->doStep(currentTimeSec, dt, …)`**，再 **`syncChildOutputsToLogger`**。  
- 最后 **`transferInputEdgesToSelf`**，**`currentTime_ = currentTimeSec + dt`**。

```149:171:AccumulatedExperience/basic_model/orchestrator/src/FmuOrchestratorCore.cpp
bool FmuOrchestratorCore::step(double currentTimeSec, double dt, std::string* errorMessage) {
  if (dt <= 0.0)
    return errorMessage ? (*errorMessage = "dt must be > 0", false) : false;
  if (state_ != FMIStepModeState) {
    if (errorMessage) *errorMessage = "step: need FMIStepModeState";
    return false;
  }

  auto& gm = GraphManager::instance();
  for (const auto& group : gm.getScheduleGroups()) {
    for (int nodeIdx : group.nodes) {
      int childIdx = nodeIdx < static_cast<int>(nodeIndexToChildIndex_.size())
                         ? nodeIndexToChildIndex_[nodeIdx]
                         : -1;
      if (childIdx >= 0)
        stepOne(childIdx, currentTimeSec, dt);
    }
  }

  transferInputEdgesToSelf();
  currentTime_ = currentTimeSec + dt;
  if (errorMessage) errorMessage->clear();
  return true;
}
```

```592:614:AccumulatedExperience/basic_model/orchestrator/src/FmuOrchestratorCore.cpp
void FmuOrchestratorCore::stepOne(int childIndex, double currentTimeSec, double dt) {
  // ... 守卫与传输入边 ...
  c.instance->doStep(currentTimeSec, dt, fmi3False,
                     &eventHandlingNeeded, &terminateSimulation,
                     &earlyReturn, &lastSuccessfulTime);

  syncChildOutputsToLogger(childIndex);
}
```

**实现注意（与「概念」区分开）**：在 `basic_model` 本条主线源码中，`stepOne`**未检查** `doStep` 返回值；若在集成树中已补上「`doStep != FMIOK` 则整步失败」的策略，其行为应是：`core.step` 返回 `false` → `onTimeAdvance` 置 `lastAdvanceOk_=false`，上层 RPC/命令可见失败。**以你正在编译的那份 `FmuOrchestratorCore.cpp` 为准即可。**

---

## 四、一句话回顾

**`StepCommand` 只决定本轮宏步 `d` → `tickSimulationStep` 按 `Orch_FixedStep` 切成若干 `h` → 每片 `TimeManager::tick(h)` → `onTimeAdvance(h)` 里先用 `VehicleLogger` 与时间语义对齐，再调 `doStep`**；成功与否通过 **`lastAdvanceOk_` / `lastAdvanceMessage_`** 回到命令层。

---

## 修订记录

- 2026-05-14：初稿，对齐 `basic_model/orchestrator` 与 `TimeManager` 当前实现（含术语表与切片语义）。
