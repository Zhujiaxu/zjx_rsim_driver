# basic_model 协作工作区操作指南

> **新进项目的人 / agent 可先阅读本文；Codex 每次启动优先读 [CODEX_CONTEXT.md](CODEX_CONTEXT.md)。** 这个目录是「人机协同的工作区」，不是临时草稿；维护方法见各子目录的 `README.md`。

---

## 与 CODEX_CONTEXT.md 的关系

本文件是 `readme/` 工作区的**协作总纲**：解释目录为什么存在、各类文档怎么维护、issue / plan / investigation 怎么流转。

[CODEX_CONTEXT.md](CODEX_CONTEXT.md) 是 Codex 的**启动配置与压缩记忆**：把本文件、当前 open issue、当前 plan、常用排障入口压成一份更短但更可执行的索引。后续会话应先读 `CODEX_CONTEXT.md`，只有任务需要细节时再打开本文件或子目录下的具体文档。

维护规则：
- 本文件维护长期稳定的协作协议。
- `CODEX_CONTEXT.md` 维护当前项目状态、路由表、近期架构结论和调试入口。
- 如果二者冲突，以更具体、更新的来源为准：user 指令 / 现场日志 / 源码 > 子目录详细文档 > 本文件 > `CODEX_CONTEXT.md`；修正后同步更新 `CODEX_CONTEXT.md`。

---

## 适用范围

本工作区覆盖 `basic_model/` 下的全部子代码库。**一份 readme/ 服务多个子项目**，issue / plan / investigation 都按 scope 区分子项目。

| 子项目 | 路径 | scope 标签 |
|--------|------|-----------|
| dataloger             | `basic_model/dataloger/`             | `DLG` |
| orchestrator          | `basic_model/orchestrator/`          | `ORC` |
| dynamic_vehicle_module| `basic_model/dynamic_vehicle_module/`| `DVM`（详细文档只维护在 `dynamic_vehicle_module/readme/`） |
| fmu_model             | `basic_model/fmu_model/`             | `FMU` |
| RSimFmuRuntime        | `basic_model/RSimFmuRuntime/`        | `RFR` |
| TimeManager           | `basic_model/TimeManager/`           | `TM`  |
| cross-cutting         | 跨子项目                              | `X`   |

跨 root 子项目的问题（例如「orchestrator 与 RSimFmuRuntime 的 FMI 状态约定不一致」）走 `X` 与对应子项目两边都登记，相互引用。涉及 DVM 的问题在 `../dynamic_vehicle_module/readme/` 登记。

---

## 目录用途

| 子目录 | 用途 | 何时打开 |
|--------|------|----------|
| [issues/](issues/) | 代码可能存在问题的清单。agent 提出，user 校验回复，状态机驱动。 | 用户问「代码有什么问题」、「重新巡检 X」或 agent 主动巡检。 |
| [plans/](plans/) | 待做计划：feature / 重构 / 修复的拆解、任务清单与验证项；强制写明改进目标 + 约束 + 成功指标。 | issue 已确认或用户布置实现任务时。 |
| [investigations/](investigations/) | 基于运行日志 + 代码做问题分析、根因定位（FAST 的 F+A 阶段）。 | 用户给出 log 路径、问「为什么 X 没工作」时。 |
| [processes/](processes/) | 某条功能在代码里的**实现流程**（调用顺序与时间语义）；与 authoritative 源码同步维护。 | 需要「这张图从命令怎么走到 FMU」、新人理解 step/tick semantics 时。 |

每个子目录下都有自己的 `README.md` 写明「文件命名 / 单条记录格式 / 状态机」，**写或读子目录前请先读对应的 README**。

`dynamic_vehicle_module/` 是独立维护入口：DVM 的 issue、plan、investigation、process 文档只放在 `../dynamic_vehicle_module/readme/`，root `readme/` 只保留 basic_model standalone 和跨根模块的协议入口，避免同一段 Host XML / `--fmu_dir` / FMI2-FMI3 / async 性能调查说明双处维护。需要 DVM 最新状态时，先读 `../dynamic_vehicle_module/readme/CODEX_CONTEXT.md`，再打开对应 DVM 详细文档。

---

## 系统思考方法对应（FAST 骨架）

```
① 现象 / 问题界定         → investigations 的 现象 / 复现条件
② 因果分析（追根因）      → investigations 的 假设 + 验证
③ 杠杆点 / 干预点         → investigations 的 结论
④ 改进目标 + 约束         → plans 的 目标三栏（强制）
⑤ 干预设计 / 任务         → plans 的 任务列表
⑥ 验证 / 反馈环           → plans 的 验证项 + 回写 issue 状态
```

`issues/` 是「②~③ 已经确认下来的固化结论」；`investigations/` 是过程；`plans/` 是从 ④ 落到 ⑥ 的工程化路径。

---

## 三种工作循环

### 1. issues/ — 巡检 & 校验回复

```
agent 巡检 → 在 issues/<NN>-<scope>.md 追加 issue（状态 🟡 待校验）
            ↓
user 在 issue 「讨论」区追加回复
            ↓
agent 下次进入时根据回复更新状态：
   ├─ 🟢 已确认 → 派生一条 plan 进 plans/
   ├─ 🔴 已驳回 → 写驳回原因，封存，不删
   └─ 🔵 待客户回复 → 不动，下次再访
```

格式细节见 [issues/README.md](issues/README.md)。

### 2. plans/ — 任务拆解（带改进目标三栏）

每份 plan 顶部强制写：
- **目标状态**（系统改完后是什么样）
- **约束**（不允许越界的边界）
- **成功指标**（怎么知道到了）

然后才是任务列表与验证项。模板见 [plans/README.md](plans/README.md)。

### 3. investigations/ — 日志驱动诊断

模板强制：每条假设可证伪 + 推翻它需要看到什么。完成后必须导回 issues/ 或 plans/，不能让 investigation 当落点。

格式细节见 [investigations/README.md](investigations/README.md)。

---

## 顶层权威文档（不要重复造轮子）

| 文件 | 角色 |
|------|------|
| `../readme.txt` | basic_model 顶层构建/调试入口（`./build.sh`、`./dev_workflow.sh`）。 |
| `../FMI.pdf` | FMI 标准参考。 |
| `../orchestrator/README.md` | orchestrator 子库说明。 |
| `../orchestrator/orchestrator中间件重构_617b0d36.plan.md` | orchestrator 既有重构计划，巡检 ORC 时优先看。 |
| `../dynamic_vehicle_module/README.md` | 动力学模块说明。 |
| `../dynamic_vehicle_module/DOCKER_UPDATE_RSIM_VEHICLE.md` | DVM Docker 更新流程。 |
| `../dataloger/README.txt` | dataloger 说明。 |
| `../TimeManager/README.txt` | TimeManager 说明。 |

**当本目录与权威文档冲突，先以权威文档为准；权威文档与现场录包/客户书面说明冲突，以后者为准。**

---

## 联动到 adapter 仓的工作区

`basic_model/` 之外的 adapter 协议适配工作区在 `项目文件/三一/adapter/` 旁边的 `agents-a65bd96371/readme/`，结构与本目录一致。
- 跨仓问题（如 adapter 与动力学模块的协议字段单位不一致）应在对应工作区各登记一条 issue 并互引。
- 通用经验（如 FAST 骨架、状态机）走本目录沉淀；adapter 专用问题留在 adapter 工作区。

---

## agent 行为约束

- 入手前先 `git status` 看一遍当前修改与未跟踪文件，避免覆盖在跑的工作。
- 不要修改顶层 `../readme.txt`、`../FMI.pdf`、各子库的 README，除非有 plan 授权或 user 明示。
- 任何 issue / plan / investigation 的更新，**追加为主，不要静默覆盖历史讨论**；状态变更必须配讨论一条。
- 引用代码用 `<子项目>/path:line` 格式（例如 `orchestrator/src/FmuOrchestratorCore.cpp:120`），便于跳转。
- 引用 issue 用 `[BLOCK-ORC-01]` 这类编号；plan / investigation 用相对路径或文件名。
- user 说「忽略 X」「驳回 Y」时，把状态设为对应值并记录原因，**不要删条目**。
- 大批量改动同一文件时优先 `Edit`，避免 `Write` 把历史讨论一并替换掉。

---

## 快速入口

- 「这次会话先看哪些」：`CODEX_CONTEXT.md` → 按任务路由打开 `issues/README.md` / `plans/README.md` / `investigations/README.md` / `processes/*.md`。
- 「巡检 open issue」：`issues/README.md` → 各 `issues/<NN>-<scope>.md` 的「状态汇总」表 → 挑非 ✅/🔴 的项推进。
- 「我已经修完一条」：在对应 issue 把状态改 ✅，引用 commit/PR；同步 plan 勾掉对应任务。
- 「user 给了一段日志」：直接进 `investigations/`，不要往 issues/ 塞过程记录。
