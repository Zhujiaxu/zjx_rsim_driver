# Codex Context - basic_model

Last updated: 2026-06-05（SANY CSV 首行自动初始位姿，并批量 100s 验证）

This is the Codex startup file for this repository. Read it before opening the rest of `readme/`. It is an index and operating configuration, not the final authority.

Conflict order:

1. User instruction in the current conversation.
2. Fresh runtime logs, reproduced command output, and current source code.
3. Subproject authoritative docs such as `readme.txt`, `FMI.pdf`, and subproject README files.
4. Detailed docs under `readme/` or, for DVM, under `dynamic_vehicle_module/readme/`.
5. This file.

## Startup Protocol

1. Run `git status --short` before editing.
2. Read this file first.
3. Classify the request using the routing table below.
4. Open only the detailed files required by that route.
5. Preserve unrelated user changes.
6. If issue/plan/process semantics change, update this file before finishing.

## Repository Scope

`readme/` covers basic_model standalone modules. DVM has its own canonical local memory under `dynamic_vehicle_module/readme/`.

| Scope | Subproject | Path | Documentation |
| --- | --- | --- | --- |
| `DLG` | dataloger | `dataloger/` | `readme/issues/01-dataloger.md` |
| `ORC` | orchestrator | `orchestrator/` | `readme/issues/02-orchestrator.md` |
| `FMU` | fmu_model | `fmu_model/` | `readme/issues/04-fmu_model.md` |
| `RFR` | RSimFmuRuntime | `RSimFmuRuntime/` | `readme/issues/05-RSimFmuRuntime.md` |
| `TM` | TimeManager | `TimeManager/` | `readme/issues/06-TimeManager.md` |
| `X` | cross-cutting | multiple root modules | `readme/issues/99-cross-cutting.md` |
| `DVM` | dynamic_vehicle_module | `dynamic_vehicle_module/` symlink to `/home/hcz/RsimPhysics/dynamic_vehicle_module` | `dynamic_vehicle_module/readme/` |

DVM details, including Host XML, `--fmu_dir`, flat `configs/*.xml`, Futian FMI2, async run, sensor tick, logging, edge timing, and performance investigations, are maintained only under `dynamic_vehicle_module/readme/`.

## File Roles

| File / Directory | Role |
| --- | --- |
| `readme/README.md` | Stable collaboration protocol for basic_model root docs. |
| `readme/CODEX_CONTEXT.md` | This compact project memory and routing index. |
| `readme/issues/` | Root module issue registries and issue protocol. |
| `readme/plans/` | Root module plan protocol. DVM plans live under `dynamic_vehicle_module/readme/plans/`. |
| `readme/investigations/` | Root module investigation protocol. DVM investigations live under `dynamic_vehicle_module/readme/investigations/`. |
| `readme/processes/` | Root standalone process docs. DVM processes live under `dynamic_vehicle_module/readme/processes/`. |

Before editing inside a subdirectory, read that subdirectory's `README.md`.

## Task Routing Table

| User Intent | First Files To Open |
| --- | --- |
| Root issue review / status | `readme/issues/README.md`, then relevant root issue file |
| Root plan work | `readme/plans/README.md`, then target root plan |
| Root investigation | `readme/investigations/README.md` |
| Standalone orchestrator manual step flow | `readme/processes/orchestrator-manual-step-flow.md` |
| DVM general context | `dynamic_vehicle_module/readme/CODEX_CONTEXT.md` |
| DVM config / Host XML / `--fmu_dir` / Futian FMI2 | `dynamic_vehicle_module/readme/processes/dvm-config-loading-flow.md`, then `dynamic_vehicle_module/readme/plans/2026-05-28-DVM-flatten-config-entry.md` and `dynamic_vehicle_module/readme/plans/2026-05-27-DVM-mixed-fmi2-fmi3-orchestrator.md` |
| DVM async `run` / frame-rate / performance | `dynamic_vehicle_module/readme/investigations/2026-05-28-DVM-async-run-framerate-shortfall.md`, then `dynamic_vehicle_module/readme/plans/2026-05-28-DVM-fmu-step-microbench.md` and `dynamic_vehicle_module/readme/plans/2026-05-28-DVM-step-microopt.md` |
| DVM graph edge timing / `timing="static"` | `dynamic_vehicle_module/readme/plans/2026-05-27-DVM-edge-timing-static.md` |
| DVM run / logging / sensor tick / bundle / Self facade | `dynamic_vehicle_module/readme/processes/`, then the matching DVM plan |
| DVM debug config / launch.json | `dynamic_vehicle_module/.vscode/launch.json` first |

## Documentation Update Rules

- Root `readme/` should not duplicate DVM details. If DVM behavior changes, update `dynamic_vehicle_module/readme/` and keep root as a pointer and summary only.
- Issue status changes must update both the summary table and discussion entry.
- Plan progress requires task/validation checkbox changes plus a discussion note.
- Investigation conclusions must point back to an issue or plan.
- Process docs describe actual code paths; update or mark stale when code changes.

## Authoritative Docs

| File | Role |
| --- | --- |
| `readme.txt` | basic_model build/debug entry point, including `./build.sh` and `./dev_workflow.sh`. |
| `FMI.pdf` | FMI standard reference. |
| `orchestrator/README.md` | orchestrator subproject description. |
| `orchestrator/orchestrator中间件重构_617b0d36.plan.md` | Existing orchestrator refactor plan; read before ORC review. |
| `dynamic_vehicle_module/README.md` | DVM project description. |
| `dynamic_vehicle_module/readme/CODEX_CONTEXT.md` | DVM-specific working memory and documentation index. |
| `dataloger/README.txt` | dataloger description. |
| `TimeManager/README.txt` | TimeManager description. |

## Current Snapshot

- Root `readme/` currently has no open root-only issues recorded in the summary tables.
- DVM issue/plan/process/investigation history is canonical in `dynamic_vehicle_module/readme/`; root keeps only routing and short summaries.
- 2026-06-01 DVM coupling update: `dynamic_vehicle_module/configs/sany_dual_motor.xml` now loads `RsimVehicle_SANY` as the single child wrapper; the wrapper directly embeds `DualMotorGearboxModel` + `RsimVehicle_SANY_Physics`, no longer loads PID, and owns the previous-frame `M_LOAD_TR` feedback internally. Explicit `timing="previous"` feedback edges are ignored by `GraphManager::buildSchedule()` when forming same-step execution order, so previous-frame physical feedback does not create an SCC scheduling cycle. Root `IntergrationFmu` now also applies Host edge `phase=init|step|always` and `timing=current|previous|static` during runtime transfer, keeping nested Integration wrappers aligned with DVM orchestrator semantics. `fmu_model/src/tests/RsimVehicle_SANYTest.cpp` now drives the wrapper through a separate `CSV_fmuModel` instance using `CSV_fmuModel/resources/configs/sany_dual_motor_smoke.xml` and `CSV_fmuModel/resources/sany_dual_motor_smoke.csv`; the current smoke is a 4 s half-torque case. `/home/hcz/RsimPhysics/Rsim_Physics/VehicleDynamic/Source/rsim/Simulate/VehicleUpdate.cpp` now treats external powertrain mode plus nonzero `IMP_M_OUT_TR` as acceleration intention for the low-speed tire/sticky logic; verified with `RsimVehicle_SANY_test` at `GB_AV_Trans` peak about `9.29e2 rpm`, `GB_M_Trans=876.624 Nm`, and `Vx` growing to about `10.24 m/s` before coast-down. The rsimphysics SANY leaf in `/home/hcz/RsimPhysics/Rsim_Physics/vehicle_fmu/RsimVehicle_SANY_Physics/` copies the real `RSimVehicle` physics library instead of `RSimVehicleLoader`, includes `resources/Mesh`, and defaults PhysX PVD off unless `RSIM_ENABLE_PVD=1`. `RSimFmuRuntime` now defaults to retaining child FMU library handles to avoid `dlclose()` hangs with threaded FMUs; set `RSIM_FMI_UNLOAD_BINARY=1` to restore unload behavior.
- Code sync on 2026-05-28 aligned the root basic_model runtime/dataloger/orchestrator with the DVM mixed FMI2/FMI3 implementation:
  - Root `RSimFmuRuntime` now includes `RSimFMI2.hpp/.cpp`, FMI2 headers, FMI2 binary platform lookup (`linux64` style), and the version-neutral `FMIInstance` common surface used by higher layers.
  - Root `dataloger` now parses FMI2 `<ScalarVariable>` metadata and Host XML edge `phase/timing`, including `timing="static"`, and `DataLogger` carries `writeSeq` / `DataVersion` for edge delivery de-duplication.
  - Root `orchestrator` now stores child instances as `std::unique_ptr<FMIInstance>`, reads child XML `fmiVersion`, instantiates FMI2/FMI3 via the common API, uses the DVM edge phase/timing/static delivery rules, and has the DVM structured FMU log event/format sink model.
  - Root `fmu_model/src/models/IntergrationFmu/IntergrationFmu.hpp` now uses the same common runtime API and child XML factory so Integration FMUs can load both FMI2 and FMI3 children.
  - Remaining root/DVM diffs are intentional peripheral differences unless a future task says otherwise: root CMake keeps local compile database settings, DVM has `README_DV_BUNDLE.txt` and wrapper include folders, and root/DVM host fixtures or old log demos may differ.
- Code re-sync on 2026-05-29 aligned the root `dataloger/include`, `orchestrator/src`, and `orchestrator/host` with the current DVM copies for configuration loading:
  - `FmiXmlSchemaDeserializer` no longer derives `GraphManager` model roots from `<FmuRepository>`; model search context is supplied later from `Orch_FmuRoot` / `Orch_ResourcePath` or DVM CLI overrides.
  - The first Host `<Module>` now records `Orch_PrimaryModuleAlias` / `Orch_PrimaryModuleType` in `VehicleLogger` for legacy short-name fallback.
  - `OrchestratorRunner` normalizes `Orch_FmuRoot` / `Orch_ResourcePath` relative to the Host XML directory, applies `Orch_CliFmuRoot` / `Orch_CliLogLevel` / `Orch_CliCommandTimeoutMs`, then syncs the final context into `GraphManager`.
  - `FmuOrchestratorCore::resolveFmuPath` now only probes `<fmuRoot>/<Module type>` and `<Orch_ResourcePath>/<Module type>`, matching DVM's tightened repository-root rule.
- P0a on 2026-05-29 started `dynamic_vehicle_module/readme/plans/2026-05-26-X-integration-csv-regression-harness.md`:
  - Root and DVM `GraphManager::NodeSpec` now carry optional `config`; `FmiXmlSchemaDeserializer` parses `Module@config` / `configName` only from `<Submodules>` and parses edges only from `<Connections>`, so `<Runtime>` / `<Regression>` remain ignored by the opposite side.
  - Root and DVM `FmuOrchestratorCore` resolve explicit child configs under each child FMU (`resources/configs/<name>.xml`, …). **2026-06-02**：config 为完整 `fmiModelDescription`；`registerChild` + `FmiSchemaPathOverride` 在 instantiate 时用 config 替代根 MD，已删除 `applyConfigToChild` / `<Parameter>` 注入。见 `readme/plans/2026-06-02-fmu-child-config-as-modelDescription.md`。
  - `HostModelDescriptionBuilder::addSubmodule(type, alias, config)` now emits `Module@config`, and `test_host_md_builder` asserts parser roundtrip into GraphManager.
  - `fmu_model/src/FMU/RSimfmi3Functions.cpp` now restores GraphManager search context after schema load for Integration FMUs: `Orch_FmuRoot` / `Orch_ResourcePath` if present, otherwise the current Integration FMU parent directory plus its resources path.
- CSV_fmuModel P0 on 2026-05-29:
  - `fmu_model/src/models/CSV_fmuModel/readme/README.md` and `PLAN.md` document the current CSVScenario direction: XML variables are the baseline, CSV columns may be a superset, and Time remains externally driven.
  - `CSV_Module::alignWithXml()` filters/sorts CSV columns by XML input/output variables using exact, case-insensitive, CSV-contains-XML, and XML-contains-CSV matching; exact multiset equality is no longer required.
  - `CsvLoadPolicy` exposes code-level `Linear` vs `Constant` 2D extrapolation and `Fail` vs `WarnSkipRow` missing-cell behavior. `CSV_ExtrapolationMode` and FMI3 Binary init/reset smoke landed on 2026-05-30.
  - `CsvTableBuilder` is the shared 2D/multi-output builder for `CSV_Module` and `TableLoader`; missing/non-numeric cells warn and skip instead of silently becoming `0`. Multi-output rows are skipped across all selected outputs together, keeping their x/time axes aligned.
  - 2026-05-30 boundary update: CSV_fmuModel remains a numeric source only; `phase=init|step|always`, `timing=current|previous|static`, and int/bool state transitions belong to `dynamic_vehicle_module/readme/plans/2026-05-30-X-state-event-transfer-layer.md`, not CSV config execution semantics.
  - 2026-06-01 verification sync: `CSV_ExtrapolationMode` is consumed during `ExitInitializationMode`, `CSV_InitMode=2` now initializes from FMI3 Binary text, and reset/re-enter initialization reuses the stored binary parameter as covered by `CSV_fmuModel_test`.
- 2026-06-02 SANY real-data experiment config:
  - `tools/convert_sany_fixed_throttle_data.py` converts `/mnt/new/Rsim_helper/项目文件/三一/实验数据采集/固定油门制动比例无人模式采集/*.csv` into `CSV_fmuModel/resources/sany_fixed_throttle_brake_unmanned/`, with zero-based `Time`, normalized `TorqueRequest` / `BrakeRequest`, steering from recorded `转角反馈` as `SteeringRequest_rad`, local position as `REF_Xo` / `REF_Yo`, speed as `REF_Vx`, heading as `REF_Yaw`, and reference altitude/lat/lon columns.
  - 2026-06-03 update: converted CSVs now include `IMP_MODE_TRANS` derived from `CurrentGear`: `0 -> 0`, `13 -> -1`, all other gears -> `2`. Reference columns were renamed to align with vehicle variable names: e.g. `GpsSpeed_mps -> REF_Vx`, local XY -> `REF_Xo` / `REF_Yo`, heading rad -> `REF_Yaw`, altitude -> `REF_Zo`.
  - 2026-06-04 steering/yaw convention update: SANY logged steering feedback is clockwise-positive while RSim steering input is counterclockwise-positive, so `tools/convert_sany_fixed_throttle_data.py` writes `SteeringRequest_rad=-radians(转角反馈)`. SANY `航向角heading` is compass-style (`0 deg` north, clockwise-positive), while RSim yaw is map-X/east zero and counterclockwise-positive, so `REF_Yaw=normalize(pi/2-radians(heading))`; do not use a plain `-heading` conversion. Re-ran the converter for all 15 fixed-throttle files (`87128` rows written, `0` skipped), synced CSV_fmuModel build resources, and verified with `ExperimentModule_Test_20260604_200709.csv` plus plots under `RSimDataRecord/ExperimentModule_Test_20260604_200709_plots/`.
  - 2026-06-05 conversion range update: `tools/convert_sany_fixed_throttle_data.py` now defaults to converting both the fixed throttle/brake collection folder and `/mnt/new/Rsim_helper/项目文件/三一/实验数据采集/转向数据采集/*.csv` into the same `sany_fixed_throttle_brake_unmanned/` resources folder. Rows with `CurrentGear=13` force `REF_GpsSpeed_kmh` / `REF_Vx` negative while keeping `IMP_MODE_TRANS=-1`. Re-ran the converter for all 29 files (`166306` rows written, `1` skipped due to an empty source numeric cell); reverse rows were checked with no positive speed values.
  - 2026-06-05 lateral/yaw-rate reference update: raw SANY CSVs include `侧向加速度` and IMU `z轴角速度`; they do not include a direct steering-wheel angular velocity column. `tools/convert_sany_fixed_throttle_data.py` now writes `REF_LateralAcc_g`, `REF_Ay` (`侧向加速度 * 9.80665`), `REF_YawRate_degps`, and `REF_YawRate` (`-radians(z轴角速度)`, matching RSim CCW-positive yaw convention). `csv_sany_realdata_fixed_throttle.xml` declares these outputs, and ExperimentModule logs/plots `REF_Ay` vs `Ay` and `REF_YawRate` vs `AVz` in `lateral_dynamics`.
  - 2026-06-05 second-pass segment cleaner: `tools/split_sany_flat_start_segments.py` cuts the converted SANY CSVs into flatter, start-from-rest experiment segments. Defaults: input `sany_fixed_throttle_brake_unmanned/`, output `CSV_fmuModel/resources/sany_flat_start_segments/`, rolling altitude window `10s`, max local altitude range `0.5m`, start speed threshold `|REF_Vx|<=0.3m/s`, min duration `10s`, min peak speed `1m/s`, and `REF_Xo/REF_Yo` rebased to segment-local `0,0`. Running defaults produced `88` segments / `94413` rows plus `segment_summary.csv`; all segments start near zero speed and build resources were synced to `fmu_model/build/CSV_fmuModel/resources/sany_flat_start_segments/`.
  - 2026-06-05 plot-fix batch: second-pass segment output now rewrites `REF_YawRate` from `REF_YawRate_degps` with the sign convention that matches `AVz` in the yaw-rate comparison plot. ExperimentModule SANY plots are now exactly 7: trajectory, speed, one gear comparison, yaw rate, steering wheel angle (`REF_SteeringRequest_rad` vs `A_StrIn1`), throttle/brake requests only, and reference altitude only. Re-ran all `88` flat-start segments with `runs/sany_flat_segments_batch_plotfix_steering_20260605_163120/summary.csv`: all return codes `0`, all plot counts `7`, and every run includes `timeseries_steering.png`.
  - 2026-06-05 start-gear filter update: `tools/split_sany_flat_start_segments.py` now defaults `--allowed-start-gears 0,1`, so second-pass segments can only start from neutral or first gear. Re-running defaults produced `22` segments / `41173` rows, with `start_gear` recorded in `segment_summary.csv` and all starts in `{0,1}`. `experiment_plot.py` now disables matplotlib axis offset/scientific notation so altitude and other large-base signals show direct tick values. Re-ran the filtered batch at `runs/sany_flat_segments_batch_startgear01_plainaxis_20260605_165031/summary.csv`: `22/22` return code `0`, all plot counts `7`; `RSimDataRecord/` was cleaned to keep only these `22` new experiment directories.
  - 2026-06-05 trim-start filter update: start gear and long stationary prefixes are now trimmed instead of discarding the whole candidate. `tools/split_sany_flat_start_segments.py` defaults `--max-start-idle-sec 5.0`; for each candidate it finds the first speed change (`|REF_Vx| > start-speed-threshold`) and chooses a low-speed start row no more than 5 s before that point, with start `CurrentGear` in `{0,1}`. `segment_summary.csv` records `movement_start_time` and `seconds_to_movement`. Re-running defaults produced `77` segments / `32901` rows, all starts in `{0,1}`, max `seconds_to_movement=5.0`, min duration `10.05 s`, min peak speed `1.259999944 m/s`. Batch `runs/sany_flat_segments_batch_trimstart5s_20260605_170343/summary.csv` passed `77/77`, all plot counts `7`; `RSimDataRecord/` was cleaned to keep only these `77` new experiment directories.
  - 2026-06-05 CSV-derived stop time: `ExperimentModule::InitializationMode()` now reads the active CSV driver's resolved `CSV_Path`, parses the last data row's `Time`, and logs that value to `Sim_stopTime`. The ExperimentModule XML `Sim_stopTime start` is `0.0` to indicate auto mode. Verified by temporarily pointing the build CSV config at `sany_flat_start_segments/2026-04-14_17_52_17.297__seg03.csv`; `ExperimentModule_test` printed `Sim_stopTime=12.4`, matching the segment's final `Time`, and returned 0. The build CSV config was restored to the default SANY file afterward.
  - `CSV_fmuModel/resources/configs/csv_sany_realdata_fixed_throttle.xml` is the child config for converted real data; it defaults to `sany_fixed_throttle_brake_unmanned/（可用）2026-04-14,18_52_17.297.csv` and declares `IMP_MODE_TRANS` plus `REF_*` outputs.
  - `ExperimentModule/modelDescription.xml` now defaults to this real-data CSV driver. It maps `TorqueRequest` / `BrakeRequest` / `SteeringRequest_rad` into `RsimVehicle_SANY` throttle / brake / steer inputs, maps CSV `IMP_MODE_TRANS` to vehicle `IMP_MODE_TRANS`, intentionally does not drive `IMP_GEAR_TRANS`, and exposes `REF_*` real-data comparison outputs plus vehicle `Xo` / `Yo` / `Yaw`.
  - `ExperimentModule/resources/configs/sany_realdata_fixed_throttle_experiment.xml` is a full parent MD copy of the default real-data experiment graph.
  - Verification: XML parse checks pass; CSV config output names all match the converted CSV header; `cmake --build fmu_model/build_csv -j2` and `cmake --build fmu_model/build_experiment -j2` pass. `RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build_experiment/ExperimentModule_test` reaches and loads `csv_sany_realdata_fixed_throttle.xml`, then currently fails inside external `/home/hcz/RsimPhysics/Rsim_Physics/vehicle_fmu/RsimVehicle_SANY_Physics` instantiate, so the remaining blocker is the physics leaf FMU environment/binary rather than the new CSV/Experiment config.
- 2026-06-04 PTU throttle-release regen update:
  - `TorqueDistModel` now supports throttle-release regenerative braking in throttle mode. When `PTU_RegenEnable=1` and `PTU_Throttle <= PTU_RegenThrottleThreshold`, it looks up a speed-based regen torque table through `PTU_RegenSpeedRpm`, writes the positive magnitude to `PTU_RegenTorque`, sets `PTU_TotalTargetTorque` negative, and then uses the normal PTU proportional allocator to split that expected torque across `PTU_OutTorque_*`. `PTU_TargetTorque` direct mode now permits negative total torque for future brake/regen requests.
  - `ptu_sany_2source.xml` enables regen by default. `RsimVehicle_SANY` feeds `gearbox.AV_Motor2` into `ptu.PTU_RegenSpeedRpm` with previous-frame timing and exposes `PTU_RegenTorque`; `ExperimentModule` logs `PTU_RegenTorque`.
  - Verification: `TorqueDistModel_test` passed with the regen case splitting `-80 Nm` total into `-53.3333 / -26.6667` for `100:50` weights. `./fmu_model/build/ExperimentModule_test` passed at `RSimDataRecord/ExperimentModule_Test_20260604_162346.csv`; around 24.5-27.5 s the PTU requests `PTU_TotalTargetTorque=-80 Nm`, gearbox commands both motors negative, and `GB_M_Trans` is about `-97.6 Nm` while `IMP_MODE_TRANS=2`. After CSV switches `IMP_MODE_TRANS=0`, PTU continues requesting regen but the current gearbox neutral branch outputs `M_Trans=0`, which remains a separate neutral-coupling modeling decision.
  - Follow-up neutral behavior: `DualMotorGearboxModel` now treats `IMP_MODE_TRANS=0` as neutral for positive drive torque but still transmits negative motor torque for regenerative braking. Positive motor commands are clipped to zero in neutral; negative commands still pass through motor regen limits and current internal gear ratios while `GearStat` reports `0`. Verified with `DualMotorGearboxModel_test` and `ExperimentModule_test` at `RSimDataRecord/ExperimentModule_Test_20260604_164130.csv`: after `IMP_MODE_TRANS=0`, e.g. around `28.5s/30.0s/32.5s`, `PTU_TotalTargetTorque=-80 Nm` and `GB_M_Trans` remains about `-97 Nm`.
  - 2026-06-04 gearbox autobox stability follow-up: `DualMotorGearboxModel` no longer runs automatic gear selection while `IMP_MODE_TRANS=0`; neutral still keeps the current mechanical gear path available for negative regen torque, but hidden internal gear no longer drifts upward while `GearStat` reports `0`. On transition from neutral to drive, it selects the lowest gear that does not exceed that gear's upshift motor-speed threshold from the current output-shaft speed, instead of exposing a stale hidden gear. `T_GEAR_HOLD_MIN` was raised to `1.25s` and autobox confirmation to `0.20s`, matching the PhysX/CarSim-style rule that autobox latency should exceed shift time. Verified with `ExperimentModule_Test_20260604_175353.csv` / `gearbox_20260604_175352.csv`: the earlier first-phase `1->2->1` loop is gone, and the 34s neutral-to-drive re-entry starts in gear 1 rather than stale gear 5. Remaining tuning gap: later upshifts are now conservative versus `REF_GearStat`, so shift thresholds/vehicle-speed strategy should be tuned separately.
  - 2026-06-04 rsimphysics low-speed driveline fix: `/home/hcz/RsimPhysics/Rsim_Physics/VehicleDynamic/Source/rsim/Vehicle/Powertrain/PowerTrainBase.cpp` now applies wheel-speed slip limiting for both positive and negative chassis speed, and also at very low speed when brake torque or regenerative/opposing drive torque is present. `/home/hcz/RsimPhysics/Rsim_Physics/VehicleDynamic/Source/rsim/Vehicle/Powertrain/PowerTrainEVCar.cpp/.hpp` now applies `IMP_CLUTCH` as an external driveline clutch factor before torsion-spring torque `mTg` is sent to the differential. Rebuilt/copied the debug physics FMU with `printf 'no\n' | FMU_COPY_DEST=.../fmu_model/build bash BuildVehicleDynamic.sh -b debug`, then verified with `ExperimentModule_Test_20260604_192956.csv` / `gearbox_20260604_192955.csv`: the earlier low-speed `GB_AV_Trans=±3759 rpm` clamp and `AV_DiffIn/M_LOAD_TR≈1e47` explosion are gone; new extrema are roughly `GB_AV_Trans=[-105,2191] rpm`, `AV_DiffIn=[-501,4650] rpm`, `M_LOAD_TR=[-1596,9692] Nm`, and 27-32s braking/neutral window stays near tens to hundreds of rpm/Nm.
  - 2026-06-04 SANY physics brake calibration: `/home/hcz/RsimPhysics/Rsim_Physics/tools/Sany.json` uses the `ControlWithPedalForce` brake model, so `TorqPreRatio` also feeds the model's nonlinear pedal-force correction; do not keep increasing it blindly. Current debug packaged FMU uses `PedalLeverRatio=92.4`, front/rear `TorqPreRatio=21003.84/8228.4`, and tire `MaxBrakeTorque=160000`. After running `tools/vehconfig_trans.py` and packaging via `FMU_COPY_DEST=.../fmu_model/build bash BuildVehicleDynamic.sh -b debug`, `ExperimentModule_Test_20260604_171252.csv` shows 0.1 brake plus `PTU_RegenTorque=80 Nm` stopping from `Vx≈10.07 m/s` at 24.0 s to `|Vx|<0.1 m/s` at 28.02 s.
- 2026-06-04 ExperimentModule plotting plan:
  - `readme/plans/2026-06-04-FMU-experiment-plot-config.md` tracks implementation progress for experiment plots and configured ref/actual error-derived columns in the parent `modelDescription.xml` annotation.
  - First implementation keeps `<Plots>` parsing local to `ExperimentModule` (no GraphManager/FmiXmlSchemaDeserializer change): `ExperimentModule.hpp` reads `<Compare>` from the current parent MD, then after successful `IntergrationFmu::DoStep(dt)` computes configured `absError` / `relError` columns already declared in `ModelVariables`.
  - 2026-06-04 follow-up: `<Plots>` no longer writes `CSV_StoredKey` or filters CSV columns. Plot/error data uses normal `ModelVariables`; CSV output keeps `CSVSerializer` default behavior unless Host explicitly sets `CSV_StoredKey`.
  - Default ExperimentModule MD and `resources/configs/sany_realdata_fixed_throttle_experiment.xml` declare `Vx_AbsError` / `Vx_RelError`, speed and gear time-series plots, and XY trajectory. `resources/tools/experiment_plot.py` renders ExperimentModule CSV + MD `<Plots>` into PNGs and `plot_index.json`; verified with `cmake --build fmu_model/build -j2`, a temporary CSV smoke, and `RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build/ExperimentModule_test` producing `RSimDataRecord/ExperimentModule_Test_20260604_144327.csv` plus plots under `RSimDataRecord/ExperimentModule_Test_20260604_144327_plots/`.
  - 2026-06-04 plot renderer follow-up: `experiment_plot.py` now aligns TimeSeries data by CSV row and splits value / absolute error / relative error into separate panels, so `Vx_RelError` spikes near zero reference speed no longer flatten the speed plot. Trajectory plots default to `align="auto"` and origin-align axes when actual/global coordinates have a large fixed offset from local reference coordinates. Re-rendered `ExperimentModule_Test_20260604_152408_plots/` and verified latest `ExperimentModule_Test_20260604_170803_plots/` plus numeric error-column consistency.
  - 2026-06-04 plotting config extension: ExperimentModule source MD and `resources/configs/sany_realdata_fixed_throttle_experiment.xml` now add control request, driveline speed, driveline torque/load, brake/regen, and shift/clutch plots. Verified with `cmake --build fmu_model/build -j2`, `./fmu_model/build/ExperimentModule_test`, and `experiment_plot.py` producing `RSimDataRecord/ExperimentModule_Test_20260604_194756.csv` plus 8 PNG plots under `RSimDataRecord/ExperimentModule_Test_20260604_194756_plots/`.
  - 2026-06-04 initial pose correction: ExperimentModule source MD and `resources/configs/sany_realdata_fixed_throttle_experiment.xml` initialize SANY at the converted CSV local origin (`Xo_INIT=0`, `Yo_INIT=0`) and use initial yaw from the corrected first CSV heading (`Yaw_INIT=-2.447649838989957 rad`). Verified with `ExperimentModule_Test_20260604_200709.csv`: at `t=0`, `Xo≈1.8e-5 m`, `Yo≈1.0e-4 m`, and yaw error is near zero; 8 plots are under `RSimDataRecord/ExperimentModule_Test_20260604_200709_plots/`.
  - 2026-06-05 unified experiment output folder: `ExperimentModule::InitializationMode()` now creates `RSimDataRecord/<CSV_FileName>_<timestamp>` before child initialization and writes `CSV_FolderPath` / `CSV_RunTimestamp`; `IntergrationFmu` recursively forwards those String parameters to child FMUs that declare them before child `exitInitializationMode`, and `CSVSerializer` can use the shared timestamp plus recursive directory creation. `CSV_fmuModel` configs, `PIDControllerModel`, and `RsimVehicle_FMI3` declare the CSV output context so hello replay outputs group correctly. Verified with hello vehicle log replay at `RSimDataRecord/ExperimentModule_Test_20260605_111127/`: parent, `csv_driver`, `PID_1`, `VehicleData`, `RSimVehicleData`, `plot_index.json`, and 6 PNGs under one-level `plots/`. The smoke still returns 8 due the existing hello assertion `gearbox torque response too small: 0`, after completing the 30 s data run.
  - 2026-06-05 SANY grouped-output verification: `RsimVehicle_SANY` now declares `CSV_RunTimestamp`; `DualMotorGearboxModel`, `TorqueDistModel`, and `TorqueDistModel/resources/configs/ptu_sany_2source.xml` declare `CSV_FolderPath` / `CSV_RunTimestamp` so recursive forwarding also reaches ptu/gearbox child serializers. Rebuilt `fmu_model/build_sany`, `build_gearbox`, and `build_torque`, restored `fmu_model/build/ExperimentModule/modelDescription.xml` to SANY default, then ran `RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build/ExperimentModule_test`: status 0, peak `GB_AV_Trans=2232.76 rpm`, peak `GB_M_Trans=9741.46 Nm`. Outputs are grouped at `RSimDataRecord/ExperimentModule_Test_20260605_113244/` with parent, `csv_driver`, `ptu`, `gearbox`, `VehicleData`, `RSimVehicleData`, `plot_index.json`, and 8 PNGs under `plots/`.
  - 2026-06-05 run folder naming update: top-level ExperimentModule XML now has `Experiment_RunName` (valueReference 192). If set, it overrides `CSV_FileName` as the run folder name seed; code trims it, strips a trailing `.csv`, replaces path separators, then appends the timestamp. Default SANY sets `Experiment_RunName="（可用）2026-04-14,18_52_17.297.csv"`. Verified status 0 with output grouped at `RSimDataRecord/（可用）2026-04-14,18_52_17.297_20260605_114300/`, including all CSVs plus `plot_index.json` and 8 PNGs under `plots/`.
  - 2026-06-05 auto plot + CSV-derived run name: `Experiment_RunName` remains an optional top-level override, but defaults to empty for SANY. If empty, `ExperimentModule` resolves the parent MD's `CSV_fmuModel` `Module@config`, reads that child config's `CSV_Path@start` basename, strips `.csv`, and uses it as the run folder name seed. `ExperimentModuleTest` is now the runner-layer plot callback: after `fmi3FreeInstance()` closes CSV files, it finds `<run_dir>/ExperimentModule_Test_*.csv` and calls `experiment_plot.py --out <run_dir>`. Verified status 0 at `RSimDataRecord/（可用）2026-04-14,18_52_17.297_20260605_115317/`: all CSVs, `plot_index.json`, and 8 PNG plots are generated automatically.
  - 2026-06-05 config cleanup: `resources/configs` has been reduced to the active SANY and hello experiment paths. Source/build retained XMLs are `CSV_fmuModel/{csv_sany_realdata_fixed_throttle.xml,csv_hello_vehicle_log_replay.xml}`, `ExperimentModule/{sany_realdata_fixed_throttle_experiment.xml,hello_vehicle_log_replay_experiment.xml}`, and `TorqueDistModel/ptu_sany_2source.xml`. Removed obsolete smoke/direct/torque-snippet/regression configs from source and build config directories, updated active module README references, and verified all remaining config XML parses. SANY default still passes with auto plots at `RSimDataRecord/（可用）2026-04-14,18_52_17.297_20260605_120021/`.
  - 2026-06-05 300s SANY run: `ExperimentModule/modelDescription.xml` and `ExperimentModule/resources/configs/sany_realdata_fixed_throttle_experiment.xml` set `Sim_stopTime start="300.0"`. Synced build MD and ran `RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build/ExperimentModule_test`: status 0, `Sim_dt=0.01`, `Sim_stopTime=300`, peak `GB_AV_Trans=3239.47 rpm`, peak `GB_M_Trans=12250.7 Nm`. Outputs and auto plots are under `RSimDataRecord/（可用）2026-04-14,18_52_17.297_20260605_120427/`; parent CSV has 30030 rows and 8 PNG plots.
  - 2026-06-05 100s SANY follow-up: `ExperimentModule/modelDescription.xml` and `ExperimentModule/resources/configs/sany_realdata_fixed_throttle_experiment.xml` now set `Sim_stopTime start="100.0"`; build MD was synced and `RSIM_FMU_ROOT=fmu_model/build/ExperimentModule ./fmu_model/build/ExperimentModule_test` passed at `RSimDataRecord/（可用）2026-04-14,18_52_17.297_20260605_123853/` with grouped CSVs and 8 auto plots under `plots/`. 50-60s mismatch is not a plot issue: converted CSV keeps `TorqueRequest=0.7`, `BrakeRequest=0`, `CurrentGear=5`, `IMP_MODE_TRANS=2`, so PTU/gearbox command positive drive torque (`PTU_TotalTargetTorque≈795-1085 Nm`, `GB_M_Trans≈942-1204 Nm`) while the raw real-data drivetrain columns show much lower/occasionally negative actual gearbox torque (`OutputTorqueGearbox` mean about `620 Nm`, min `-77 Nm`) and real speed decelerates. Current replay treats `请求扭矩%` as throttle/torque intent, not actual drivetrain torque, so exact longitudinal replay needs either actual torque feedback mapping/calibration or additional resistance/grade/vehicle-load modeling.
  - 2026-06-05 CSV-derived SANY initial pose: `ExperimentModule::InitializationMode()` now resolves the active CSV child config, opens the selected `CSV_Path`, reads the first data row, and logs `REF_Xo/REF_Yo/REF_Zo/REF_Yaw/REF_Vx` into `Xo_INIT/Yo_INIT/Zo_INIT/Yaw_INIT/Speed_INIT` before the existing `Self -> vehicle phase=init` edges are delivered. This lets SANY experiments switch only `CSV_Path` without per-file hand-written pose parameters. Verified by rebuilding `ExperimentModule_test` and running all 15 converted SANY CSVs for 100s; every run produced one parent CSV, `plot_index.json`, and 8 PNGs under a CSV-named run folder. 13/15 test processes returned 0; `2026-04-14,17_57_17.297.csv` and `（不可用）2026-04-14,19_02_17.297.csv` returned 8 only because the test's final gearbox response assertion saw `GB_M_Trans=0`, but both completed the 100s data run and auto plots. Configs were restored to the default `（可用）2026-04-14,18_52_17.297.csv` after the batch. Nonzero `Speed_INIT` is delivered to `Vehicle_1`, but the SANY physics leaf still reports a different first-step `Vx` for some moving-start files; position and yaw align to the CSV first row.
- Verification on 2026-05-28:
  - `cmake --build RSimFmuRuntime/build -j2`
  - `cmake --build dataloger/build -j2`
  - `cmake -S orchestrator -B orchestrator/build_codex_sync_clean -DCMAKE_PREFIX_PATH=/tmp/basic_model_sync_prefix -DCMAKE_EXPORT_COMPILE_COMMANDS=ON && cmake --build orchestrator/build_codex_sync_clean -j2`
  - `cmake -S fmu_model -B fmu_model/build_codex_integration_sync -DPKG_NAME=IntergrationFmu -DCMAKE_PREFIX_PATH=/tmp/basic_model_sync_prefix -DCMAKE_EXPORT_COMPILE_COMMANDS=ON && cmake --build fmu_model/build_codex_integration_sync -j2`
  - `./dataloger/build/datalogger_test`
  - `./orchestrator/build_codex_sync_clean/orchestrator_time_smoke && ./orchestrator/build_codex_sync_clean/test_host_md_builder` (`orchestrator_time_smoke` reports allowed bootstrap failure because fixture sub-FMUs are absent; Host MD builder tests pass).
- Verification on 2026-05-29:
  - `cmake --build RSimFmuRuntime/build -j2`
  - `cmake --build dataloger/build -j2`
  - `cmake --install RSimFmuRuntime/build --prefix /tmp/basic_model_dvm_sync_prefix`
  - `cmake --install dataloger/build --prefix /tmp/basic_model_dvm_sync_prefix`
  - `cmake -S orchestrator -B orchestrator/build_codex_dvm_sync -DCMAKE_PREFIX_PATH=/tmp/basic_model_dvm_sync_prefix -DCMAKE_EXPORT_COMPILE_COMMANDS=ON && cmake --build orchestrator/build_codex_dvm_sync -j2`
  - `./dataloger/build/datalogger_test`
  - `./orchestrator/build_codex_dvm_sync/orchestrator_time_smoke` (allowed bootstrap failure because fixture sub-FMUs are absent)
  - `./orchestrator/build_codex_dvm_sync/test_host_md_builder`
  - `cmake -S fmu_model -B fmu_model/build_codex_dvm_sync_integration -DPKG_NAME=IntergrationFmu -DCMAKE_PREFIX_PATH=/tmp/basic_model_dvm_sync_prefix -DCMAKE_EXPORT_COMPILE_COMMANDS=ON && cmake --build fmu_model/build_codex_dvm_sync_integration --target fmu_IntergrationFmu -j2`
- Verification on 2026-05-29 for `Module@config` P0a:
  - `cmake --build RSimFmuRuntime/build -j2`
  - `cmake --build dataloger/build -j2`
  - `cmake --install RSimFmuRuntime/build --prefix /tmp/basic_model_config_p0a_prefix`
  - `cmake --install dataloger/build --prefix /tmp/basic_model_config_p0a_prefix`
  - `cmake -S orchestrator -B orchestrator/build_codex_config_p0a -DCMAKE_PREFIX_PATH=/tmp/basic_model_config_p0a_prefix -DCMAKE_EXPORT_COMPILE_COMMANDS=ON`
  - `cmake --build orchestrator/build_codex_config_p0a -j2`
  - `cmake -S fmu_model -B fmu_model/build_codex_config_p0a_integration -DPKG_NAME=IntergrationFmu -DCMAKE_PREFIX_PATH=/tmp/basic_model_config_p0a_prefix -DCMAKE_EXPORT_COMPILE_COMMANDS=ON`
  - `cmake --build fmu_model/build_codex_config_p0a_integration --target fmu_IntergrationFmu -j2` (only the pre-existing `char *buf = ""` warning)
  - `./dataloger/build/datalogger_test`
  - `./orchestrator/build_codex_config_p0a/test_host_md_builder`
  - `./orchestrator/build_codex_config_p0a/orchestrator_time_smoke` (allowed bootstrap validation failure because fixture sub-FMUs are absent)

## DVM Readme Snapshot

Use DVM files as source of truth; the bullets below are just a fast map.

- Issues:
  - `dynamic_vehicle_module/readme/issues/03-dynamic_vehicle_module.md` keeps `[BLOCK-DVM-02]` orchestrator-only / BindSync / sensor / Host MD regression and `[HIGH-DVM-03]` Self control logging + t=0 forwarding.
  - `dynamic_vehicle_module/readme/issues/99-cross-cutting.md` keeps `[BLOCK-X-01]` FMI3 CS direct `exitInitializationMode` already entering Step Mode.
- Configuration and mixed FMI:
  - `dynamic_vehicle_module/readme/processes/dvm-config-loading-flow.md` documents current flat `configs/*.xml` Host XML selection and the model repository rules: command-line config, exe-adjacent `modelDescription.xml`, exe-adjacent `configs/modelDescription.xml`; model search only from `--fmu_dir`, `Orch_FmuRoot`, `Orch_ResourcePath`.
  - `dynamic_vehicle_module/readme/plans/2026-05-27-DVM-mixed-fmi2-fmi3-orchestrator.md` records DVM mixed FMI2/FMI3 loading; Futian full init/step may still be blocked by TruckSim license.
  - `dynamic_vehicle_module/readme/plans/2026-05-28-DVM-flatten-config-entry.md` records the DVM config flattening work; `configs/futian2.xml` is the Futian FMI2 entry.
  - `dynamic_vehicle_module/readme/plans/2026-05-27-DVM-edge-timing-static.md` adds `timing="static"` for per-step held inputs; Futian ZGND/MUX edges use it.
- Performance:
  - `dynamic_vehicle_module/readme/investigations/2026-05-28-DVM-async-run-framerate-shortfall.md` concludes async 100 Hz shortfall is not CSV sync write; Debug Futian run had Start-to-Start median about 16 ms, and `Do Tick Vehicle` median about 13 ms.
  - `dynamic_vehicle_module/readme/plans/2026-05-28-DVM-fmu-step-microbench.md` landed temporary per-step probes. Debug Futian sample split core step roughly into `in=3245us`, `doStep=3075us`, `out=686us`, `self=3119us`, `total=9859us`.
  - `dynamic_vehicle_module/readme/plans/2026-05-28-DVM-step-microopt.md` is Phase 2, pending: Release/RelWithDebInfo measurement first, then batch input/self edge transfer, FMI2 VR direct pass, and log formatting short-circuit.
- Regression / smoke:
  - `dynamic_vehicle_module/readme/plans/2026-05-19-DVM-rpc-regression-harness.md` documents `vehicle_rpc_regression` and `tools/run_dvm_regression.py`.
  - DVM debug launch configs live in `dynamic_vehicle_module/.vscode/launch.json`, not root `.vscode`.

## DVM Debug / Smoke Entrypoints

Keep DVM debug configs in `dynamic_vehicle_module/.vscode/launch.json`.

Typical DVM server config:

```text
program: ${workspaceFolder}/build/source/rsim_vehicle
cwd: ${workspaceFolder}/build
args:
  --orch_host_md=${workspaceFolder}/configs/futian2
  --fmu_dir=${workspaceFolder}/vehicle_fmu
  --port=9000
  --streaming_port=9001
  --logfile_dir=/tmp/rsim_vehicle_logs
```

Typical async client args:

```text
--host=127.0.0.1
--port=9000
--poll_timeout_sec=5
--poll_interval_ms=100
--run_frequency=100
--fixed_step_sec=0.01
--min_time_advance_sec=0.2
--min_frame_advance=3
```

## Quick Commands

- Build/debug entry: see `readme.txt`.
- Check root/DVM runtime diff: `git diff --no-index -- RSimFmuRuntime dynamic_vehicle_module/rsim_rsimfmuruntime`.
- Check root/DVM orchestrator diff: `git diff --no-index -- orchestrator dynamic_vehicle_module/rsim_orchestrator`.
- Check root/DVM dataloger diff: `git diff --no-index -- dataloger dynamic_vehicle_module/rsim_dataloger`.
