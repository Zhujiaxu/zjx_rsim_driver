# TimeManager 问题清单

涉及代码：`basic_model/TimeManager/`

参考文档：
- `../../TimeManager/README.txt`
- `../../readme.txt`（顶层构建/调试入口）

scope 标签：`TM`

## 状态汇总

> 当前无 open issue。新增条目后请同步本表。

| 编号 | 状态 | 简述 |
|------|------|------|
| —    | —    | 暂无 |

> 状态枚举、单条格式与回复速记见 [README.md](README.md)。

---

<!-- 新 issue 从下方追加。模板：

### [BLOCK-TM-01] <一句话>

- 协议 / 期望: ...
- 代码: TimeManager/path:line
- 影响: ...
- 修复建议: ...
- 状态: 🟡 待校验
- 讨论:
  - (Agent <YYYY-MM-DD>) 初次提出

-->
