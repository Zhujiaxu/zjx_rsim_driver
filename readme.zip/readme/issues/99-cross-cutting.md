# 跨子项目问题清单（cross-cutting）

涉及代码：跨 `basic_model/` 的多个 root 子项目（DLG/ORC/FMU/RFR/TM 之间的接口、单位、节拍、坐标系等）。

scope 标签：`X`

## 何时登记到这里

- 一个根因牵动两个或更多子项目的修改（例如「单位约定不一致」「step 节拍约定不一致」「FMU 变量命名约定不一致」）。
- 单个子项目内部已经能独立解决的问题不要登记到这里，留在对应的 `0N-<scope>.md`。
- 在 `99-cross-cutting.md` 登记**主条**，并在涉及的单子项目文件里写**指向条**（一句话 + 链接），双向可查。

## 状态汇总

| 编号 | 状态 | 涉及子项目 | 简述 |
|------|------|-----------|------|
| - | - | - | 当前 root 侧无单独维护的 open cross-cutting issue |

> 状态枚举、单条格式与回复速记见 [README.md](README.md)。

> DVM 相关 cross-cutting 历史问题已迁移到
> `../../dynamic_vehicle_module/readme/issues/99-cross-cutting.md`，root 侧不再复制 DVM 细节。

---

<!-- 新 issue 从下方追加。模板：

### [BLOCK-X-01] <一句话>

- 涉及子项目: ORC + RFR
- 协议 / 期望: ...
- 代码: ORC: orchestrator/path:line ；RFR: RSimFmuRuntime/path:line
- 影响: ...
- 修复建议: ...
- 状态: 🟡 待校验
- 讨论:
  - (Agent <YYYY-MM-DD>) 初次提出

记得在涉及的 root 子项目 issue 文件里各加一条「指向条」，例如：
> 见 [99-cross-cutting.md#BLOCK-X-01]：<一句话>。
-->
