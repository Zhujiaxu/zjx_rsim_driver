# issues/ — 问题清单 & 校验回复协议

本子目录是「人机协同 review」工作面：agent 巡检发现的可能问题写到这里，user 在每条「讨论」区里回复，agent 据此推动状态机。

## 文件分布（按子项目）

| 文件 | 范围 | scope |
|------|------|-------|
| [01-dataloger.md](01-dataloger.md) | `basic_model/dataloger/` | `DLG` |
| [02-orchestrator.md](02-orchestrator.md) | `basic_model/orchestrator/` | `ORC` |
| [04-fmu_model.md](04-fmu_model.md) | `basic_model/fmu_model/` | `FMU` |
| [05-RSimFmuRuntime.md](05-RSimFmuRuntime.md) | `basic_model/RSimFmuRuntime/` | `RFR` |
| [06-TimeManager.md](06-TimeManager.md) | `basic_model/TimeManager/` | `TM`  |
| [99-cross-cutting.md](99-cross-cutting.md) | 跨子项目 | `X` |

DVM 相关 issue 只在 `../../dynamic_vehicle_module/readme/issues/` 维护；root 侧不再复制 DVM 问题正文。

> 跨子项目问题在 `99-cross-cutting.md` 登记主条，并在涉及的单子项目文件里写指向条（一句话 + 链接），双向可查。

## 严重度分级

| 标签 | 含义 |
|------|------|
| `[BLOCK]` | 必现严重错误（驻车反向、档位错位、单位差 10×/100×、节拍错乱等） |
| `[HIGH]`  | 大概率不正确，依赖现场协议/录包/书面确认 |
| `[MED]`   | 量纲/范围有疑虑，clamp/截断后影响受限但物理上值得校准 |
| `[LOW]`   | 占位常量、文档自身不一致、命名错位但语义近似等 |

## 单条 issue 格式（必须严格遵循）

```markdown
### [BLOCK-ORC-01] FmuOrchestratorCore step 对齐策略不一致

- 协议 / 期望: <协议 / 设计文档要求>
- 代码: <现状> (子项目/path:line，例如 orchestrator/src/FmuOrchestratorCore.cpp:120)
- 影响: <下游会出现什么现象>
- 修复建议: <动作>
- 状态: 🟡 待校验
- 讨论:
  - (Agent 2026-05-07) 初次提出
  - (User) ...
  - (Agent 2026-05-08) 根据 user 回复改为 🟢，已派生 plan plans/2026-05-08-fix-orc-step.md
```

要点：
- 标题 `### [<严重度>-<scope>-<NN>] <一句话>`，scope 用上表的三字母（DLG/ORC/FMU/RFR/TM/X）。编号一旦分配不复用、不修改。
- 「状态」与「讨论」必须**同时**更新；只改状态不留讨论会让 user 看不到原因。
- 讨论按时间倒序追加新条，不动旧条。
- 引用代码用 `<子项目>/path:line`；引用其它 issue 用编号；引用 plan / investigation 用相对路径。

## 状态机

| 图标 | 状态 | 含义 | 谁能改 |
|------|------|------|--------|
| 🟡 | 待校验 | agent 提出，user 未回复 | agent 创建 |
| 🟢 | 已确认 | user 确认问题成立，需要修复 | user 标记，agent 据此派生 plan |
| 🔴 | 已驳回 | user 否定，封存 | user 标记，agent 不再触碰 |
| 🔵 | 待客户回复 | 需要外部信息（客户/录包）才能定 | 任一方标记，回复到位后转 🟢 / 🔴 |
| ✅ | 已修复 | 修复并验证完成，附 commit/PR | agent 在 plan 完成时同步 |

变更示例：
- user 在讨论里写一行 `- (User) 确认问题，按建议改`，agent 下次入场把状态改 🟢，并在 `plans/` 起一份对应 plan，本条「讨论」追加 `- (Agent <date>) 已派生 plans/...`。
- user 写 `- (User) 这个不修，行为符合现场约定`，agent 改 🔴，写 `- (Agent <date>) 标记 🔴，原因：现场约定`。
- user 写 `- (User) 等客户回复`，agent 改 🔵，不再频繁巡检。

## user 回复速记（直接复制）

```
- (User) 确认 / 修
- (User) 驳回，原因：...
- (User) 等客户回复，外部信息：...
- (User) 修复请走 plan: plans/<文件名>
```

## 维护规则

- **绝不删除已封存的条目**（包括 🔴）。历史信息是后续 review 的语料。
- 同一问题 scope 改了，比如 `[MED-ORC-08]` 拆成两条，原条改 ✅ 并写明拆分目标，新条另起编号。
- 顶部「状态汇总」表与正文状态必须保持一致。修改正文状态时同步表。
- 如果发现一条 issue 与既有重复，**不要静默合并**：在新条目里写 `- (Agent) 与 [BLOCK-X-01] 重复，状态 🔴` 并指向对方。
- 跨子项目 issue 在 `99-cross-cutting.md` 登记主条，单子项目文件里只放指向条；不要两边都写完整描述（容易漂移）。
