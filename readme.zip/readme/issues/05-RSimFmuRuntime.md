# RSimFmuRuntime 问题清单

涉及代码：`basic_model/RSimFmuRuntime/`

参考文档：
- `../../RSimFmuRuntime/`（无独立 README）
- `../../readme.txt`（顶层构建/调试入口）
- `../../FMI.pdf`（FMI 标准）

scope 标签：`RFR`

## 状态汇总

| 编号 | 状态 | 简述 |
|------|------|------|
| - | - | 当前 root `RSimFmuRuntime/` 无单独维护的 open issue |

> 状态枚举、单条格式与回复速记见 [README.md](README.md)。

> DVM 内嵌 `rsim_rsimfmuruntime` 的历史问题已迁移到
> `../../dynamic_vehicle_module/readme/issues/05-RSimFmuRuntime.md`，root 侧不再复制 DVM 细节。

---

<!-- 新 issue 从下方追加。模板：

### [BLOCK-RFR-01] <一句话>

- 协议 / 期望: ...
- 代码: RSimFmuRuntime/path:line
- 影响: ...
- 修复建议: ...
- 状态: 🟡 待校验
- 讨论:
  - (Agent <YYYY-MM-DD>) 初次提出

-->
