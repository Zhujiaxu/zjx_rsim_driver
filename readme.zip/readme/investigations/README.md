# investigations/ — 日志驱动调查协议

本子目录是「过程记录」：现象、假设、对照日志/代码逐条验证、最终结论。**结论不是落点**——结论要么导回 `issues/` 形成新条目，要么导出 `plans/` 起一份修复计划。

DVM 相关调查只在 `../../dynamic_vehicle_module/readme/investigations/` 维护；root 侧不再复制 DVM 调查正文，包括 async run 帧率、Futian FMI2、传感器/日志链路等问题分析。

对应系统思考骨架（FAST）：本目录覆盖 **① 现象界定 + ② 因果分析 + ③ 杠杆点识别**；④~⑥ 阶段在 `plans/`。

## 文件命名

```
<日期>-<scope>-<现象关键词>.md
```

例：
- `2026-05-08-FMU-variable-metadata-mismatch.md`
- `2026-05-08-ORC-step-drift.md`
- `2026-05-09-X-yaw-90-deg-bias.md`

scope 用 root 侧 `DLG/ORC/FMU/RFR/TM/X` 六选一；DVM 调查在 `../../dynamic_vehicle_module/readme/investigations/`。日期取**调查开始日期**。

---

## investigation 模板

```markdown
# <现象简述>

- 创建日期: 2026-05-08
- 状态: 🔍 调查中 / ✅ 结论 / 🔴 无结论 / ⏸ 等数据
- scope: ORC（与文件名一致）
- 关联 issue: [BLOCK-ORC-01]（如已存在；调查中产生的新发现走「产出」段落）

## 现象（FAST · F）

user 描述 / 截图 / 抽样数据。原话尽量保留。

## 复现条件（FAST · F）

- 触发命令: `./dev_workflow.sh test replay`
- 现场状态: 哪个分支 / 哪份录包 / 哪台机器
- 相关 PR / commit: <若有>

## 日志位置（FAST · F）

- /media/.../basic_model/build/dev_loop_logs/<时间戳>/...   —— `<这条日志能看到什么>`
- /path/to/录包.pcap —— …

> 这一节是后续 agent 接力的关键。**不要写「日志在用户那」**，要写绝对路径或最少给一段抓包命令。

## 关联代码 / 协议

- `orchestrator/src/FmuOrchestratorCore.cpp:120`
- `fmu_model/...`
- `../../FMI.pdf` 第 X 节

## 假设清单（FAST · A，每条必须可证伪）

| 编号 | 假设 | 推翻它需要看到什么 |
|------|------|--------------------|
| H1 | brake_pressure 单位是 Pa 而不是 MPa | 静止稳态值 ≈ 1e5 量级 |
| H2 | step 累积漂移来自浮点累加 | 用 long double 累加后漂移 < 1e-12 |

> 假设要可证伪。「可能是单位错了」不是假设；「单位是 Pa，因为静止值 1e5 量级」是假设。

## 验证过程（FAST · A）

- 验证 H1：
  - 操作：`grep brake_pressure_w11 /path/to/sany_adapter_*.csv | head`
  - 观察：稳态值 1.0e5 ~ 5.0e5
  - 结论：H1 成立 → 单位是 Pa
- 验证 H2：
  - …

## 结论 / 杠杆点（FAST · ③）

简明结论 + 落点：

- step 漂移来自调度边界，写 issue: 见 `issues/02-orchestrator.md` 中新增 [BLOCK-ORC-XX]
- 修复落地走 plan: `plans/2026-05-08-ORC-fix-step-boundary.md`

## 讨论

- (Agent 2026-05-08) 调查开始，H1/H2 待验
- (User) ...
- (Agent 2026-05-09) H1 成立，已派生 issue + plan
```

---

## 状态机

| 图标 | 状态 | 含义 |
|------|------|------|
| 🔍 | 调查中 | 假设已列，验证未完 |
| ⏸ | 等数据 | 缺少日志 / 录包 / 客户回复 |
| ✅ | 结论 | 落点写明（导回 issue / 导出 plan） |
| 🔴 | 无结论 | 现有信息不足以判断；保留作为后续触发点 |

## 与 issues/ / plans/ 的关系

- 调查发现的代码问题 → 在 `issues/<NN>-<scope>.md` 里**新增**条目（不要把过程塞进 issues/）。
- 调查发现的根因要修 → 起 `plans/<日期>-<scope>-<...>.md`。
- investigation 文件本身**只读**化：写完结论后只追加讨论，不改主体。
- 同一现象再次出现：起新 investigation，**不复用旧文件**；新文件「关联 issue」里互引。
- 跨子项目的调查 scope 选 `X`，但「关联 issue」段要把涉及的子项目 issue 都列出来。

## 维护规则

- 「日志位置」里的路径若是临时录包，请同时附上「保存到何处长期归档」（例：`scp 到 nas:/data/2026-05/...`），避免日志被清后调查失锚。
- 不要在 investigation 里写未验证的修复建议——修复建议属于 plan。
- 当 user 给出新的现象但还无法判断范围时，**先开 investigation**（不开 issue）；现象→根因→issue/plan 的路径要保持清晰。
- basic_model 项目跑 `./dev_workflow.sh loop` 默认把日志写到 `build/dev_loop_logs/`；调查时优先把这一目录作为「日志位置」，避免每个调查重新约定路径。
